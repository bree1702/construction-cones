import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import toast, { Toaster } from 'react-hot-toast';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { MapView } from './components/MapView';
import { AIInsightsPanel } from './components/AIInsightsPanel';
import { RealTimeAnalytics } from './components/RealTimeAnalytics';
import { EmployeeManagement } from './components/EmployeeManagement';
import { WeatherWidget } from './components/WeatherWidget';
import { NotificationSettings, NotificationSettings as NotificationSettingsType } from './components/NotificationSettings';
import { AuthModal, UserProfile as UserProfileType } from './components/AuthModal';
import { TeamSharingPanel } from './components/TeamSharingPanel';
import { UserProfile } from './components/UserProfile';
import { ConstructionZone } from './types';
import { useAIInsights } from './hooks/useAIInsights';
import { useRealTimeData } from './hooks/useRealTimeData';
import { useWeatherData } from './hooks/useWeatherData';
import constructionData from './assets/construction-zones-2025-06-19(1).json';
import { Menu, X } from 'lucide-react';

function App() {
  const [zones, setZones] = useState<ConstructionZone[]>([]);
  const [selectedZone, setSelectedZone] = useState<ConstructionZone | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeView, setActiveView] = useState<'map' | 'analytics' | 'ai' | 'employees'>('map');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notificationSettingsOpen, setNotificationSettingsOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(true);
  const [teamSharingOpen, setTeamSharingOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<UserProfileType | null>(null);
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettingsType>({
    enabled: true,
    frequency: '10min',
    types: {
      aiInsights: true,
      alerts: true,
      systemStatus: false,
      maintenance: true
    },
    sound: false,
    desktop: true
  });

  // Use real-time data hook with notification settings
  const realTimeZones = useRealTimeData(zones, notificationSettings);
  
  // Use AI insights hook
  const { insights, alerts, isAnalyzing } = useAIInsights(realTimeZones);

  // Use weather data hook
  const { weatherData } = useWeatherData();

  // Check for project access from URL
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const projectId = urlParams.get('project');
    const accessType = urlParams.get('access');
    
    if (projectId && accessType === 'guest') {
      // Auto-fill guest access with project ID
      setAuthModalOpen(true);
    }
  }, []);

  useEffect(() => {
    // Load the construction zone data
    setZones(constructionData as ConstructionZone[]);
    // Select the first zone by default
    if (constructionData.length > 0) {
      setSelectedZone(constructionData[0] as ConstructionZone);
    }

    // Show welcome notification only if notifications are enabled and user is authenticated
    if (currentUser && notificationSettings.enabled && notificationSettings.types.systemStatus) {
      toast.success(`🚧 Welcome ${currentUser.name}! AI Construction Zone Manager Activated!`, {
        duration: 4000,
        position: 'top-right',
      });
    }

    // Simulate real-time alerts
    setTimeout(() => {
      if (currentUser && notificationSettings.enabled && notificationSettings.types.aiInsights) {
        toast('🤖 AI Analysis Complete - 5 insights generated', {
          icon: '🧠',
          duration: 3000,
        });
      }
    }, 3000);

  }, [currentUser, notificationSettings.enabled, notificationSettings.types.systemStatus, notificationSettings.types.aiInsights]);

  // Show alerts as notifications based on settings
  useEffect(() => {
    if (!currentUser || !notificationSettings.enabled || !notificationSettings.types.alerts) return;

    alerts.forEach(alert => {
      if (alert.severity === 'critical') {
        toast.error(`🚨 ${alert.message}`, { duration: 6000 });
      } else if (alert.severity === 'warning') {
        toast(`⚠️ ${alert.message}`, { duration: 4000 });
      }
    });
  }, [alerts, currentUser, notificationSettings.enabled, notificationSettings.types.alerts]);

  const activeZones = realTimeZones.filter(zone => zone.isActive).length;
  const totalCones = realTimeZones.reduce((total, zone) => total + zone.cones.length, 0);
  const connectedDevices = realTimeZones.flatMap(zone => zone.cones).filter(cone => cone.isConnected !== false).length;

  const handleZoneSelect = (zone: ConstructionZone) => {
    setSelectedZone(zone);
    setSidebarOpen(false); // Close sidebar on mobile after selection
    
    if (currentUser && notificationSettings.enabled && notificationSettings.types.systemStatus) {
      toast(`📍 Selected zone: ${zone.name}`, { duration: 2000 });
    }
  };

  const handleNotificationSettingsChange = (newSettings: NotificationSettingsType) => {
    setNotificationSettings(newSettings);
    toast.success('Notification settings updated!', { duration: 2000 });
  };

  const handleAuth = (user: UserProfileType) => {
    setCurrentUser(user);
    setAuthModalOpen(false);
    
    // Generate project ID if supervisor
    if (user.role === 'supervisor' && !user.projectId) {
      user.projectId = `proj_${Date.now()}`;
    }
    
    toast.success(`Welcome, ${user.name}! You have ${user.role} access.`, { duration: 3000 });
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setAuthModalOpen(true);
    toast('Signed out successfully', { duration: 2000 });
  };

  const handleAddZone = (zoneData: Omit<ConstructionZone, 'id' | 'createdAt'>) => {
    const newZone: ConstructionZone = {
      ...zoneData,
      id: `zone_${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    
    setZones(prevZones => [...prevZones, newZone]);
    setSelectedZone(newZone);
    
    toast.success(`🎉 Project "${newZone.name}" created successfully!`, {
      duration: 4000,
      position: 'top-right',
    });
  };

  const viewButtons = [
    { id: 'map', label: 'Smart Map', icon: '🗺️' },
    { id: 'analytics', label: 'Analytics', icon: '📊' },
    { id: 'ai', label: 'AI Center', icon: '🤖' },
    { id: 'employees', label: 'Employees', icon: '👥' }
  ];

  // Show auth modal if no user is authenticated
  if (!currentUser) {
    return (
      <div className="h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100">
        <AuthModal
          isOpen={authModalOpen}
          onClose={() => setAuthModalOpen(false)}
          onAuth={handleAuth}
        />
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-gradient-to-br from-gray-50 to-gray-100 overflow-hidden">
      <Toaster 
        position="top-right"
        toastOptions={{
          className: 'bg-white shadow-lg border border-gray-200 text-sm',
          duration: 3000,
        }}
      />
      
      <Header 
        activeZones={activeZones} 
        totalCones={totalCones}
        connectedDevices={connectedDevices}
        aiInsightsCount={insights.length}
        onMenuClick={() => setSidebarOpen(!sidebarOpen)}
        onNotificationSettingsClick={() => setNotificationSettingsOpen(true)}
        notificationSettings={notificationSettings}
        currentUser={currentUser}
        onUserProfileClick={() => {}}
        onOpenSharing={() => setTeamSharingOpen(true)}
        onLogout={handleLogout}
      />
      
      <div className="flex-1 flex overflow-hidden relative">
        {/* Mobile Sidebar Overlay */}
        {sidebarOpen && (
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}
        
        {/* Sidebar */}
        <div className={`
          fixed lg:relative inset-y-0 left-0 z-50 lg:z-auto
          transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} 
          lg:translate-x-0 transition-transform duration-300 ease-in-out
          w-80 lg:w-96 flex-shrink-0
        `}>
          <Sidebar
            zones={realTimeZones}
            selectedZone={selectedZone}
            onZoneSelect={handleZoneSelect}
            searchTerm={searchTerm}
            onSearchChange={setSearchTerm}
            onClose={() => setSidebarOpen(false)}
            currentUser={currentUser}
            onAddZone={handleAddZone}
          />
        </div>
        
        <div className="flex-1 flex flex-col p-3 lg:p-6 space-y-3 lg:space-y-6 min-w-0">
          {/* View Toggle */}
          <div className="flex items-center justify-between">
            <div className="flex space-x-1 lg:space-x-2 bg-white p-1 rounded-lg shadow-sm border border-gray-200 overflow-x-auto">
              {viewButtons.map((button) => (
                <motion.button
                  key={button.id}
                  onClick={() => setActiveView(button.id as any)}
                  className={`flex items-center space-x-1 lg:space-x-2 px-2 lg:px-4 py-2 rounded-md text-xs lg:text-sm font-medium transition-all whitespace-nowrap ${
                    activeView === button.id
                      ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-md'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <span className="text-sm lg:text-base">{button.icon}</span>
                  <span className="hidden sm:inline">{button.label}</span>
                </motion.button>
              ))}
            </div>

            <div className="flex items-center space-x-3">
              {isAnalyzing && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex items-center space-x-2 bg-purple-50 px-2 lg:px-4 py-2 rounded-lg border border-purple-200"
                >
                  <div className="animate-spin w-3 h-3 lg:w-4 lg:h-4 border-2 border-purple-600 border-t-transparent rounded-full"></div>
                  <span className="text-xs lg:text-sm font-medium text-purple-700 hidden sm:inline">AI Analyzing...</span>
                </motion.div>
              )}

              {/* User Profile */}
              <UserProfile
                user={currentUser}
                onLogout={handleLogout}
                onOpenSharing={() => setTeamSharingOpen(true)}
              />
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 grid grid-cols-1 xl:grid-cols-3 gap-3 lg:gap-6 min-h-0">
            <div className="xl:col-span-2 min-h-0 relative z-10">
              {activeView === 'map' && (
                <motion.div
                  key="map"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="h-full min-h-[400px] lg:min-h-0 relative z-10"
                >
                  <MapView zones={realTimeZones} selectedZone={selectedZone} />
                </motion.div>
              )}

              {activeView === 'analytics' && (
                <motion.div
                  key="analytics"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="h-full min-h-[400px] lg:min-h-0 bg-white rounded-xl shadow-lg border border-gray-200 p-3 lg:p-6 overflow-y-auto relative z-10"
                >
                  <RealTimeAnalytics zones={realTimeZones} />
                </motion.div>
              )}

              {activeView === 'ai' && (
                <motion.div
                  key="ai"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="h-full min-h-[400px] lg:min-h-0 overflow-y-auto relative z-10"
                >
                  <AIInsightsPanel 
                    insights={insights} 
                    alerts={alerts} 
                    isAnalyzing={isAnalyzing} 
                  />
                </motion.div>
              )}

              {activeView === 'employees' && (
                <motion.div
                  key="employees"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="h-full min-h-[400px] lg:min-h-0 overflow-y-auto relative z-10"
                >
                  <EmployeeManagement userPermissions={currentUser.permissions} />
                </motion.div>
              )}
            </div>

            {/* Side Panel - Hidden on mobile, shown on larger screens */}
            <div className="hidden xl:block space-y-6">
              {/* Weather Widget */}
              <WeatherWidget />

              {/* Quick Stats */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white rounded-xl shadow-lg border border-gray-200 p-6"
              >
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Live Status</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">System Health</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span className="text-green-700 font-semibold">Optimal</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">AI Confidence</span>
                    <span className="font-semibold text-purple-700">94%</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Response Time</span>
                    <span className="font-semibold text-blue-700">1.2s</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Predictions</span>
                    <span className="font-semibold text-orange-700">{alerts.length} Active</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Update Frequency</span>
                    <span className="font-semibold text-blue-700">
                      {notificationSettings.frequency === 'realtime' ? 'Real-time' :
                       notificationSettings.frequency === '5min' ? '5 min' :
                       notificationSettings.frequency === '10min' ? '10 min' :
                       notificationSettings.frequency === '30min' ? '30 min' : '1 hour'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Notifications</span>
                    <div className="flex items-center space-x-2">
                      <div className={`w-2 h-2 rounded-full ${notificationSettings.enabled ? 'bg-green-500' : 'bg-gray-400'}`}></div>
                      <span className={`font-semibold ${notificationSettings.enabled ? 'text-green-700' : 'text-gray-500'}`}>
                        {notificationSettings.enabled ? 'Enabled' : 'Disabled'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Access Level</span>
                    <span className={`font-semibold capitalize ${
                      currentUser.role === 'supervisor' ? 'text-blue-700' : 'text-green-700'
                    }`}>
                      {currentUser.role}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Location</span>
                    <span className="font-semibold text-purple-700">
                      {weatherData?.location || 'Loading...'}
                    </span>
                  </div>
                </div>
              </motion.div>

              {/* Weather & Traffic */}
              {selectedZone?.weatherConditions && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 }}
                  className="bg-white rounded-xl shadow-lg border border-gray-200 p-6"
                >
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Environmental</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Weather</span>
                      <span className="font-medium">{selectedZone.weatherConditions.conditions}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Temperature</span>
                      <span className="font-medium">{Math.round(selectedZone.weatherConditions.temperature)}°C</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Wind Speed</span>
                      <span className="font-medium">{Math.round(selectedZone.weatherConditions.windSpeed)} km/h</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Traffic Flow</span>
                      <span className={`font-medium capitalize ${
                        selectedZone.trafficFlow?.congestionLevel === 'high' ? 'text-red-600' :
                        selectedZone.trafficFlow?.congestionLevel === 'medium' ? 'text-yellow-600' :
                        'text-green-600'
                      }`}>
                        {selectedZone.trafficFlow?.congestionLevel || 'Normal'}
                      </span>
                    </div>
                  </div>
                </motion.div>
              )}
            </div>
          </div>

          {/* Mobile Quick Stats - Shown only on mobile */}
          <div className="xl:hidden bg-white rounded-xl shadow-lg border border-gray-200 p-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-lg font-bold text-green-700">{activeZones}</div>
                <div className="text-xs text-gray-600">Active Zones</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-blue-700">{connectedDevices}</div>
                <div className="text-xs text-gray-600">Connected</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Notification Settings Modal */}
      <NotificationSettings
        isOpen={notificationSettingsOpen}
        onClose={() => setNotificationSettingsOpen(false)}
        onSettingsChange={handleNotificationSettingsChange}
        currentSettings={notificationSettings}
      />

      {/* Team Sharing Modal */}
      {currentUser.role === 'supervisor' && (
        <TeamSharingPanel
          isOpen={teamSharingOpen}
          onClose={() => setTeamSharingOpen(false)}
          projectId={currentUser.projectId || 'default'}
          projectName={selectedZone?.name || 'Construction Project'}
          userRole={currentUser.role}
        />
      )}
    </div>
  );
}

export default App;