import React from 'react';
import { motion } from 'framer-motion';
import { Cloud, Sun, Wind, Droplets, Eye, Thermometer, Gauge, Zap } from 'lucide-react';
import { useWeatherData } from '../hooks/useWeatherData';

export const WeatherWidget: React.FC = () => {
  const { weatherData, location, loading, error } = useWeatherData();

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
        <div className="flex items-center space-x-3 mb-4">
          <div className="animate-spin w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full"></div>
          <span className="text-gray-600">Loading weather data...</span>
        </div>
      </div>
    );
  }

  if (error || !weatherData) {
    return (
      <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
        <div className="text-center text-gray-500">
          <Cloud className="w-8 h-8 mx-auto mb-2 text-gray-400" />
          <p className="text-sm">Weather data unavailable</p>
        </div>
      </div>
    );
  }

  const getWeatherIcon = (conditions: string) => {
    if (conditions.includes('Clear') || conditions.includes('Sunny')) return Sun;
    if (conditions.includes('Cloud')) return Cloud;
    if (conditions.includes('Wind')) return Wind;
    return Cloud;
  };

  const WeatherIcon = getWeatherIcon(weatherData.conditions);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-br from-blue-50 to-cyan-100 rounded-xl shadow-lg border border-blue-200 p-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-blue-900">Current Weather</h3>
          <p className="text-sm text-blue-700">{weatherData.location}</p>
        </div>
        <div className="p-3 bg-white/50 rounded-lg">
          <WeatherIcon className="w-6 h-6 text-blue-600" />
        </div>
      </div>

      {/* Main Temperature */}
      <div className="text-center mb-6">
        <div className="text-4xl font-bold text-blue-900 mb-1">
          {weatherData.temperature}°C
        </div>
        <div className="text-sm text-blue-700 mb-2">{weatherData.conditions}</div>
        <div className="text-xs text-blue-600">
          Feels like {weatherData.feelsLike}°C
        </div>
      </div>

      {/* Weather Details Grid */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-white/50 p-3 rounded-lg">
          <div className="flex items-center space-x-2 mb-1">
            <Droplets className="w-4 h-4 text-blue-600" />
            <span className="text-xs font-medium text-blue-700">Humidity</span>
          </div>
          <span className="text-sm font-bold text-blue-900">{weatherData.humidity}%</span>
        </div>

        <div className="bg-white/50 p-3 rounded-lg">
          <div className="flex items-center space-x-2 mb-1">
            <Wind className="w-4 h-4 text-blue-600" />
            <span className="text-xs font-medium text-blue-700">Wind</span>
          </div>
          <span className="text-sm font-bold text-blue-900">{weatherData.windSpeed} km/h</span>
        </div>

        <div className="bg-white/50 p-3 rounded-lg">
          <div className="flex items-center space-x-2 mb-1">
            <Eye className="w-4 h-4 text-blue-600" />
            <span className="text-xs font-medium text-blue-700">Visibility</span>
          </div>
          <span className="text-sm font-bold text-blue-900">{weatherData.visibility.toFixed(1)} km</span>
        </div>

        <div className="bg-white/50 p-3 rounded-lg">
          <div className="flex items-center space-x-2 mb-1">
            <Gauge className="w-4 h-4 text-blue-600" />
            <span className="text-xs font-medium text-blue-700">Pressure</span>
          </div>
          <span className="text-sm font-bold text-blue-900">{weatherData.pressure} hPa</span>
        </div>
      </div>

      {/* UV Index */}
      <div className="bg-white/50 p-3 rounded-lg mb-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-2">
            <Zap className="w-4 h-4 text-orange-600" />
            <span className="text-xs font-medium text-blue-700">UV Index</span>
          </div>
          <span className="text-sm font-bold text-blue-900">{weatherData.uvIndex}</span>
        </div>
        <div className="w-full bg-blue-200 rounded-full h-2">
          <div 
            className={`h-2 rounded-full ${
              weatherData.uvIndex < 3 ? 'bg-green-500' :
              weatherData.uvIndex < 6 ? 'bg-yellow-500' :
              weatherData.uvIndex < 8 ? 'bg-orange-500' : 'bg-red-500'
            }`}
            style={{ width: `${Math.min(100, (weatherData.uvIndex / 11) * 100)}%` }}
          ></div>
        </div>
        <div className="text-xs text-blue-600 mt-1">
          {weatherData.uvIndex < 3 ? 'Low' :
           weatherData.uvIndex < 6 ? 'Moderate' :
           weatherData.uvIndex < 8 ? 'High' : 'Very High'}
        </div>
      </div>

      {/* Forecast */}
      <div className="bg-white/50 p-3 rounded-lg">
        <h4 className="text-xs font-semibold text-blue-700 mb-2 uppercase tracking-wide">
          Construction Impact
        </h4>
        <p className="text-sm text-blue-800">{weatherData.forecast}</p>
      </div>

      {/* Last Updated */}
      <div className="text-center mt-4 pt-3 border-t border-blue-200">
        <p className="text-xs text-blue-600">
          Last updated: {new Date().toLocaleTimeString()}
        </p>
      </div>
    </motion.div>
  );
};