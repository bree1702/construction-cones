import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Clock, AlertTriangle, Activity, Battery, Thermometer, Wifi, Brain, Edit, Eye } from 'lucide-react';
import { ConstructionZone } from '../types';

interface ZoneCardProps {
  zone: ConstructionZone;
  onSelect: (zone: ConstructionZone) => void;
  isSelected: boolean;
  userPermissions?: {
    viewAll: boolean;
    editZones: boolean;
    manageTeam: boolean;
    exportData: boolean;
  };
}

export const ZoneCard: React.FC<ZoneCardProps> = ({ zone, onSelect, isSelected, userPermissions }) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const avgBattery = zone.cones.reduce((sum, cone) => sum + (cone.batteryLevel || 100), 0) / zone.cones.length;
  const connectedCones = zone.cones.filter(cone => cone.isConnected !== false).length;
  const riskScore = zone.riskScore || Math.floor(Math.random() * 40) + 10;

  return (
    <motion.div 
      className={`bg-white rounded-xl shadow-sm border-2 transition-all duration-300 cursor-pointer hover:shadow-lg ${
        isSelected 
          ? 'border-orange-500 ring-2 ring-orange-200 shadow-lg' 
          : 'border-gray-200 hover:border-gray-300'
      }`}
      onClick={() => onSelect(zone)}
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      layout
    >
      <div className="p-4 lg:p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-bold text-gray-900 mb-2 truncate">{zone.name}</h3>
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${zone.isActive ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`}></div>
                <span className={`text-sm font-semibold ${zone.isActive ? 'text-green-700' : 'text-gray-500'}`}>
                  {zone.isActive ? 'Active' : 'Inactive'}
                </span>
              </div>
              
              <div className="flex items-center space-x-1">
                <Wifi className="w-4 h-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-700">
                  {connectedCones}/{zone.cones.length}
                </span>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col items-end space-y-2 flex-shrink-0">
            <div className="flex items-center space-x-1 bg-orange-50 px-3 py-1 rounded-full">
              <AlertTriangle className="w-4 h-4 text-orange-600" />
              <span className="text-sm font-bold text-orange-700">{zone.cones.length}</span>
            </div>
            
            <div className={`px-2 py-1 rounded-full text-xs font-medium ${
              riskScore < 30 ? 'bg-green-100 text-green-700' :
              riskScore < 70 ? 'bg-yellow-100 text-yellow-700' :
              'bg-red-100 text-red-700'
            }`}>
              Risk: {riskScore}
            </div>

            {/* Access indicator */}
            <div className="flex items-center space-x-1">
              {userPermissions?.editZones ? (
                <Edit className="w-3 h-3 text-blue-600" title="Can edit" />
              ) : (
                <Eye className="w-3 h-3 text-green-600" title="View only" />
              )}
            </div>
          </div>
        </div>
        
        {/* Real-time Metrics */}
        <div className="grid grid-cols-3 gap-2 lg:gap-3 mb-4">
          <div className="bg-gradient-to-br from-blue-50 to-cyan-100 p-2 lg:p-3 rounded-lg border border-blue-200">
            <div className="flex items-center space-x-1 lg:space-x-2 mb-1">
              <Battery className="w-3 h-3 lg:w-4 lg:h-4 text-blue-600" />
              <span className="text-xs font-medium text-blue-700">Battery</span>
            </div>
            <span className="text-sm lg:text-lg font-bold text-blue-900">{Math.round(avgBattery)}%</span>
          </div>
          
          <div className="bg-gradient-to-br from-green-50 to-emerald-100 p-2 lg:p-3 rounded-lg border border-green-200">
            <div className="flex items-center space-x-1 lg:space-x-2 mb-1">
              <Activity className="w-3 h-3 lg:w-4 lg:h-4 text-green-600" />
              <span className="text-xs font-medium text-green-700">Active</span>
            </div>
            <span className="text-sm lg:text-lg font-bold text-green-900">{connectedCones}</span>
          </div>
          
          <div className="bg-gradient-to-br from-orange-50 to-red-100 p-2 lg:p-3 rounded-lg border border-orange-200">
            <div className="flex items-center space-x-1 lg:space-x-2 mb-1">
              <Thermometer className="w-3 h-3 lg:w-4 lg:h-4 text-orange-600" />
              <span className="text-xs font-medium text-orange-700">Temp</span>
            </div>
            <span className="text-sm lg:text-lg font-bold text-orange-900">
              {Math.round(zone.cones.reduce((sum, cone) => sum + (cone.temperature || 22), 0) / zone.cones.length)}°C
            </span>
          </div>
        </div>
        
        {/* Zone Info */}
        <div className="space-y-2 lg:space-y-3 mb-4">
          <div className="flex items-center space-x-2 text-gray-600">
            <MapPin className="w-4 h-4 flex-shrink-0" />
            <span className="text-sm">
              {zone.cones.length} smart cones deployed
            </span>
          </div>
          
          <div className="flex items-center space-x-2 text-gray-600">
            <Clock className="w-4 h-4 flex-shrink-0" />
            <span className="text-sm">
              Created {formatDate(zone.createdAt)}
            </span>
          </div>

          {zone.workersCount && (
            <div className="flex items-center space-x-2 text-gray-600">
              <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-xs text-white font-bold">{zone.workersCount}</span>
              </div>
              <span className="text-sm">
                {zone.workersCount} workers on site
              </span>
            </div>
          )}
        </div>

        {/* AI Recommendations */}
        {zone.aiRecommendations && zone.aiRecommendations.length > 0 && (
          <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-3 rounded-lg border border-purple-200 mb-4">
            <div className="flex items-center space-x-2 mb-2">
              <Brain className="w-4 h-4 text-purple-600" />
              <span className="text-xs font-semibold text-purple-700 uppercase tracking-wide">AI Insight</span>
            </div>
            <p className="text-sm text-purple-800 line-clamp-2">{zone.aiRecommendations[0]}</p>
          </div>
        )}
        
        {/* Coverage Indicator */}
        <div className="pt-4 border-t border-gray-100">
          <div className="flex items-center justify-between">
            <span className="text-xs text-gray-500 uppercase tracking-wide font-medium">
              Zone Coverage
            </span>
            <div className="flex space-x-1">
              {[...Array(5)].map((_, i) => (
                <motion.div 
                  key={i} 
                  className={`w-2 h-2 rounded-full ${
                    i < Math.min(5, Math.ceil(zone.cones.length / 4)) ? 'bg-orange-400' : 'bg-gray-200'
                  }`}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: i * 0.1 }}
                />
              ))}
            </div>
          </div>
          
          {/* Weather & Traffic Info */}
          {zone.weatherConditions && (
            <div className="mt-3 flex items-center justify-between text-xs text-gray-500">
              <span className="truncate">Weather: {zone.weatherConditions.conditions}</span>
              <span className="ml-2 flex-shrink-0">Traffic: {zone.trafficFlow?.congestionLevel || 'normal'}</span>
            </div>
          )}

          {/* Access Level Indicator */}
          <div className="mt-2 flex items-center justify-between text-xs">
            <span className="text-gray-500">Access Level:</span>
            <span className={`font-medium ${
              userPermissions?.editZones ? 'text-blue-600' : 'text-green-600'
            }`}>
              {userPermissions?.editZones ? 'Full Control' : 'View Only'}
            </span>
          </div>
        </div>
      </div>
    </motion.div>
  );
};