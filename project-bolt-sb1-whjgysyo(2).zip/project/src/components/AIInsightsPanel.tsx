import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, TrendingUp, AlertTriangle, Lightbulb, Clock, Target, Activity, Zap, BarChart3, Settings } from 'lucide-react';
import { AIInsight, PredictiveAlert } from '../types';

interface AIInsightsPanelProps {
  insights: AIInsight[];
  alerts: PredictiveAlert[];
  isAnalyzing: boolean;
}

export const AIInsightsPanel: React.FC<AIInsightsPanelProps> = ({ insights, alerts, isAnalyzing }) => {
  const [activeTab, setActiveTab] = useState<'insights' | 'alerts' | 'analytics' | 'settings'>('insights');

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'text-red-600 bg-red-50 border-red-200';
      case 'high': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      default: return 'text-blue-600 bg-blue-50 border-blue-200';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'text-red-600 bg-red-100';
      case 'warning': return 'text-orange-600 bg-orange-100';
      default: return 'text-blue-600 bg-blue-100';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'safety': return AlertTriangle;
      case 'efficiency': return TrendingUp;
      case 'maintenance': return Target;
      default: return Lightbulb;
    }
  };

  const aiTabs = [
    { id: 'insights', label: 'AI Insights', icon: Lightbulb, count: insights.length },
    { id: 'alerts', label: 'Predictive Alerts', icon: Clock, count: alerts.length },
    { id: 'analytics', label: 'AI Analytics', icon: BarChart3, count: null },
    { id: 'settings', label: 'AI Settings', icon: Settings, count: null }
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden relative z-10">
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 px-4 lg:px-6 py-4">
        <div className="flex items-center space-x-3 mb-4">
          <div className="p-2 bg-white/20 rounded-lg">
            <Brain className="w-5 h-5 lg:w-6 lg:h-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">AI Command Center</h3>
            <p className="text-purple-100 text-sm">Real-time insights & predictions</p>
          </div>
        </div>

        {/* AI Tab Navigation */}
        <div className="flex space-x-1 bg-white/10 p-1 rounded-lg">
          {aiTabs.map((tab) => {
            const IconComponent = tab.icon;
            return (
              <motion.button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 flex items-center justify-center space-x-1 lg:space-x-2 px-2 lg:px-3 py-2 rounded-md text-xs lg:text-sm font-medium transition-all ${
                  activeTab === tab.id
                    ? 'bg-white text-purple-700 shadow-sm'
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <IconComponent className="w-4 h-4" />
                <span className="hidden sm:inline">{tab.label}</span>
                {tab.count !== null && (
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    activeTab === tab.id 
                      ? 'bg-purple-100 text-purple-700' 
                      : 'bg-white/20 text-white'
                  }`}>
                    {tab.count}
                  </span>
                )}
              </motion.button>
            );
          })}
        </div>
      </div>

      <div className="p-4 lg:p-6 space-y-4 lg:space-y-6 max-h-[600px] overflow-y-auto">
        {/* Analysis Status */}
        <AnimatePresence>
          {isAnalyzing && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex items-center space-x-3 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-200"
            >
              <div className="animate-spin w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full"></div>
              <span className="text-blue-700 font-medium text-sm lg:text-base">AI analyzing construction zones...</span>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence mode="wait">
          {/* AI Insights Tab */}
          {activeTab === 'insights' && (
            <motion.div
              key="insights"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <h4 className="text-lg font-semibold text-gray-900 flex items-center space-x-2">
                <Lightbulb className="w-5 h-5 text-yellow-600" />
                <span>AI Insights</span>
              </h4>
              <div className="space-y-4">
                {insights.map((insight) => {
                  const IconComponent = getTypeIcon(insight.type);
                  return (
                    <motion.div
                      key={insight.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`p-3 lg:p-4 rounded-lg border ${getPriorityColor(insight.priority)}`}
                    >
                      <div className="flex items-start space-x-3">
                        <div className="p-2 rounded-lg bg-current/10 flex-shrink-0">
                          <IconComponent className="w-4 h-4" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
                            <h5 className="font-semibold text-gray-900 text-sm lg:text-base">{insight.title}</h5>
                            <span className="text-xs bg-white px-2 py-1 rounded border flex-shrink-0">
                              {insight.confidence}% confidence
                            </span>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">{insight.description}</p>
                          <div className="bg-white/50 p-3 rounded border border-current/20">
                            <p className="text-sm font-medium text-gray-900">💡 Recommendation:</p>
                            <p className="text-sm text-gray-700 mt-1">{insight.recommendation}</p>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* Predictive Alerts Tab */}
          {activeTab === 'alerts' && (
            <motion.div
              key="alerts"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <h4 className="text-lg font-semibold text-gray-900 flex items-center space-x-2">
                <Clock className="w-5 h-5 text-purple-600" />
                <span>Predictive Alerts</span>
              </h4>
              <div className="space-y-3">
                {alerts.map((alert) => (
                  <motion.div
                    key={alert.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className={`p-3 lg:p-4 rounded-lg border-l-4 ${getSeverityColor(alert.severity)} border-l-current`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="font-medium text-gray-900 text-sm lg:text-base">{alert.message}</p>
                        <p className="text-sm text-gray-600 mt-1">
                          ETA: {Math.floor(alert.timeToEvent / 60)}h {alert.timeToEvent % 60}m
                          <span className="ml-2 text-xs bg-gray-100 px-2 py-1 rounded">
                            {alert.confidence}% confidence
                          </span>
                        </p>
                      </div>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {alert.actions.map((action, index) => (
                        <span
                          key={index}
                          className="text-xs bg-white px-2 py-1 rounded border border-gray-200"
                        >
                          {action}
                        </span>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {/* AI Analytics Tab */}
          {activeTab === 'analytics' && (
            <motion.div
              key="analytics"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <h4 className="text-lg font-semibold text-gray-900 flex items-center space-x-2">
                <BarChart3 className="w-5 h-5 text-blue-600" />
                <span>AI Analytics</span>
              </h4>

              {/* AI Performance Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-gradient-to-br from-blue-50 to-cyan-100 p-4 rounded-lg border border-blue-200">
                  <div className="flex items-center space-x-2 mb-3">
                    <Activity className="w-5 h-5 text-blue-600" />
                    <h5 className="font-semibold text-blue-900">Model Performance</h5>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-blue-700">Accuracy</span>
                      <span className="font-bold text-blue-900">94.2%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-blue-700">Prediction Rate</span>
                      <span className="font-bold text-blue-900">87.5%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-blue-700">Response Time</span>
                      <span className="font-bold text-blue-900">1.2s</span>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-green-50 to-emerald-100 p-4 rounded-lg border border-green-200">
                  <div className="flex items-center space-x-2 mb-3">
                    <TrendingUp className="w-5 h-5 text-green-600" />
                    <h5 className="font-semibold text-green-900">Optimization Results</h5>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-green-700">Traffic Flow</span>
                      <span className="font-bold text-green-900">+23%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-green-700">Safety Score</span>
                      <span className="font-bold text-green-900">+15%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-green-700">Efficiency</span>
                      <span className="font-bold text-green-900">+31%</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* AI Learning Progress */}
              <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                <h5 className="font-semibold text-purple-900 mb-3">AI Learning Progress</h5>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-purple-700">Pattern Recognition</span>
                      <span className="text-purple-900 font-medium">92%</span>
                    </div>
                    <div className="w-full bg-purple-200 rounded-full h-2">
                      <div className="bg-purple-600 h-2 rounded-full" style={{ width: '92%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-purple-700">Predictive Accuracy</span>
                      <span className="text-purple-900 font-medium">87%</span>
                    </div>
                    <div className="w-full bg-purple-200 rounded-full h-2">
                      <div className="bg-purple-600 h-2 rounded-full" style={{ width: '87%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-purple-700">Optimization Engine</span>
                      <span className="text-purple-900 font-medium">95%</span>
                    </div>
                    <div className="w-full bg-purple-200 rounded-full h-2">
                      <div className="bg-purple-600 h-2 rounded-full" style={{ width: '95%' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* AI Settings Tab */}
          {activeTab === 'settings' && (
            <motion.div
              key="settings"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <h4 className="text-lg font-semibold text-gray-900 flex items-center space-x-2">
                <Settings className="w-5 h-5 text-gray-600" />
                <span>AI Configuration</span>
              </h4>

              {/* AI Model Settings */}
              <div className="space-y-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h5 className="font-semibold text-gray-900 mb-3">Model Configuration</h5>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-sm font-medium text-gray-700">Predictive Analysis</span>
                        <p className="text-xs text-gray-500">Enable AI-powered predictions</p>
                      </div>
                      <div className="w-12 h-6 bg-green-500 rounded-full relative">
                        <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full"></div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-sm font-medium text-gray-700">Real-time Learning</span>
                        <p className="text-xs text-gray-500">Continuously improve models</p>
                      </div>
                      <div className="w-12 h-6 bg-green-500 rounded-full relative">
                        <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full"></div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-sm font-medium text-gray-700">Auto-optimization</span>
                        <p className="text-xs text-gray-500">Automatic system optimization</p>
                      </div>
                      <div className="w-12 h-6 bg-gray-300 rounded-full relative">
                        <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full"></div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h5 className="font-semibold text-gray-900 mb-3">Analysis Frequency</h5>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    <option>Real-time (every 5 seconds)</option>
                    <option>High (every 30 seconds)</option>
                    <option>Medium (every 2 minutes)</option>
                    <option>Low (every 10 minutes)</option>
                  </select>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h5 className="font-semibold text-gray-900 mb-3">Confidence Threshold</h5>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Minimum confidence for alerts</span>
                      <span className="font-medium">75%</span>
                    </div>
                    <input 
                      type="range" 
                      min="50" 
                      max="95" 
                      defaultValue="75" 
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-xs text-gray-500">
                      <span>50%</span>
                      <span>95%</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};