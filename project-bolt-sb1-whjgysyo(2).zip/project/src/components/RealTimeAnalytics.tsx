import React from 'react';
import { motion } from 'framer-motion';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Activity, Zap, Thermometer, Wifi, AlertCircle, TrendingUp } from 'lucide-react';
import { ConstructionZone } from '../types';

interface RealTimeAnalyticsProps {
  zones: ConstructionZone[];
}

export const RealTimeAnalytics: React.FC<RealTimeAnalyticsProps> = ({ zones }) => {
  // Generate mock time series data
  const generateTimeSeriesData = () => {
    const data = [];
    for (let i = 23; i >= 0; i--) {
      data.push({
        time: `${i}:00`,
        traffic: 800 + Math.random() * 400,
        safety: 85 + Math.random() * 15,
        efficiency: 70 + Math.random() * 25
      });
    }
    return data;
  };

  const timeSeriesData = generateTimeSeriesData();

  const coneStatusData = zones.flatMap(zone => zone.cones).reduce((acc, cone) => {
    const status = cone.isConnected ? 'Connected' : 'Offline';
    acc[status] = (acc[status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const pieData = Object.entries(coneStatusData).map(([name, value]) => ({ name, value }));
  const COLORS = ['#10B981', '#EF4444', '#F59E0B'];

  const avgBattery = zones.flatMap(zone => zone.cones)
    .reduce((sum, cone) => sum + (cone.batteryLevel || 0), 0) / zones.flatMap(zone => zone.cones).length;

  const avgTemperature = zones.flatMap(zone => zone.cones)
    .reduce((sum, cone) => sum + (cone.temperature || 0), 0) / zones.flatMap(zone => zone.cones).length;

  const connectedCones = zones.flatMap(zone => zone.cones).filter(cone => cone.isConnected).length;
  const totalCones = zones.flatMap(zone => zone.cones).length;

  return (
    <div className="space-y-4 lg:space-y-6">
      {/* Real-time Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-green-50 to-emerald-100 p-4 lg:p-6 rounded-xl border border-green-200"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-green-700">Connectivity</p>
              <p className="text-xl lg:text-2xl font-bold text-green-900">{Math.round((connectedCones / totalCones) * 100)}%</p>
              <p className="text-xs text-green-600">{connectedCones}/{totalCones} online</p>
            </div>
            <Wifi className="w-6 h-6 lg:w-8 lg:h-8 text-green-600" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-br from-blue-50 to-cyan-100 p-4 lg:p-6 rounded-xl border border-blue-200"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-blue-700">Avg Battery</p>
              <p className="text-xl lg:text-2xl font-bold text-blue-900">{Math.round(avgBattery)}%</p>
              <p className="text-xs text-blue-600">All devices</p>
            </div>
            <Zap className="w-6 h-6 lg:w-8 lg:h-8 text-blue-600" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-gradient-to-br from-orange-50 to-red-100 p-4 lg:p-6 rounded-xl border border-orange-200"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-orange-700">Temperature</p>
              <p className="text-xl lg:text-2xl font-bold text-orange-900">{Math.round(avgTemperature)}°C</p>
              <p className="text-xs text-orange-600">Average</p>
            </div>
            <Thermometer className="w-6 h-6 lg:w-8 lg:h-8 text-orange-600" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-gradient-to-br from-purple-50 to-pink-100 p-4 lg:p-6 rounded-xl border border-purple-200"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-purple-700">Risk Score</p>
              <p className="text-xl lg:text-2xl font-bold text-purple-900">{zones[0]?.riskScore || 0}</p>
              <p className="text-xs text-purple-600">AI calculated</p>
            </div>
            <AlertCircle className="w-6 h-6 lg:w-8 lg:h-8 text-purple-600" />
          </div>
        </motion.div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 lg:gap-6">
        {/* Traffic & Safety Trends */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white p-4 lg:p-6 rounded-xl shadow-lg border border-gray-200"
        >
          <div className="flex items-center space-x-2 mb-4">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg font-semibold text-gray-900">24-Hour Trends</h3>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={timeSeriesData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="time" stroke="#666" fontSize={12} />
              <YAxis stroke="#666" fontSize={12} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
                  fontSize: '12px'
                }}
              />
              <Line type="monotone" dataKey="traffic" stroke="#3B82F6" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="safety" stroke="#10B981" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="efficiency" stroke="#F59E0B" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Device Status Distribution */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white p-4 lg:p-6 rounded-xl shadow-lg border border-gray-200"
        >
          <div className="flex items-center space-x-2 mb-4">
            <Activity className="w-5 h-5 text-green-600" />
            <h3 className="text-lg font-semibold text-gray-900">Device Status</h3>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex justify-center flex-wrap gap-2 lg:gap-4 mt-4">
            {pieData.map((entry, index) => (
              <div key={entry.name} className="flex items-center space-x-2">
                <div 
                  className="w-3 h-3 rounded-full" 
                  style={{ backgroundColor: COLORS[index % COLORS.length] }}
                ></div>
                <span className="text-xs lg:text-sm text-gray-600">{entry.name}: {entry.value}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};