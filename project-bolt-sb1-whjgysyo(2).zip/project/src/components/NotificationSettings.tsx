import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Settings, Bell, BellOff, Clock, X, Check } from 'lucide-react';

interface NotificationSettingsProps {
  isOpen: boolean;
  onClose: () => void;
  onSettingsChange: (settings: NotificationSettings) => void;
  currentSettings: NotificationSettings;
}

export interface NotificationSettings {
  enabled: boolean;
  frequency: 'realtime' | '5min' | '10min' | '30min' | '1hour';
  types: {
    aiInsights: boolean;
    alerts: boolean;
    systemStatus: boolean;
    maintenance: boolean;
  };
  sound: boolean;
  desktop: boolean;
}

export const NotificationSettings: React.FC<NotificationSettingsProps> = ({
  isOpen,
  onClose,
  onSettingsChange,
  currentSettings
}) => {
  const [settings, setSettings] = useState<NotificationSettings>(currentSettings);

  const frequencyOptions = [
    { value: 'realtime', label: 'Real-time', description: 'Instant notifications' },
    { value: '5min', label: '5 minutes', description: 'Every 5 minutes' },
    { value: '10min', label: '10 minutes', description: 'Every 10 minutes' },
    { value: '30min', label: '30 minutes', description: 'Every 30 minutes' },
    { value: '1hour', label: '1 hour', description: 'Every hour' }
  ];

  const notificationTypes = [
    { key: 'aiInsights', label: 'AI Insights', description: 'New AI recommendations and analysis' },
    { key: 'alerts', label: 'Critical Alerts', description: 'Safety and equipment warnings' },
    { key: 'systemStatus', label: 'System Status', description: 'Connection and performance updates' },
    { key: 'maintenance', label: 'Maintenance', description: 'Scheduled maintenance reminders' }
  ];

  const handleSave = () => {
    onSettingsChange(settings);
    onClose();
  };

  const updateSetting = (key: keyof NotificationSettings, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const updateNotificationType = (type: keyof NotificationSettings['types'], enabled: boolean) => {
    setSettings(prev => ({
      ...prev,
      types: { ...prev.types, [type]: enabled }
    }));
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="bg-white rounded-xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-6 py-4 rounded-t-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-white/20 rounded-lg">
                  <Settings className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">Notification Settings</h3>
                  <p className="text-blue-100 text-sm">Customize your alerts and updates</p>
                </div>
              </div>
              <motion.button
                onClick={onClose}
                className="p-2 text-white/80 hover:text-white hover:bg-white/20 rounded-lg transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <X className="w-5 h-5" />
              </motion.button>
            </div>
          </div>

          <div className="p-6 space-y-6">
            {/* Master Toggle */}
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                {settings.enabled ? (
                  <Bell className="w-5 h-5 text-blue-600" />
                ) : (
                  <BellOff className="w-5 h-5 text-gray-400" />
                )}
                <div>
                  <h4 className="font-semibold text-gray-900">Enable Notifications</h4>
                  <p className="text-sm text-gray-600">Turn all notifications on or off</p>
                </div>
              </div>
              <motion.button
                onClick={() => updateSetting('enabled', !settings.enabled)}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  settings.enabled ? 'bg-blue-600' : 'bg-gray-300'
                }`}
                whileTap={{ scale: 0.95 }}
              >
                <motion.div
                  className="absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm"
                  animate={{ x: settings.enabled ? 26 : 2 }}
                  transition={{ type: "spring", stiffness: 500, damping: 30 }}
                />
              </motion.button>
            </div>

            {/* Frequency Settings */}
            <div className={`space-y-4 ${!settings.enabled ? 'opacity-50 pointer-events-none' : ''}`}>
              <div className="flex items-center space-x-2">
                <Clock className="w-5 h-5 text-purple-600" />
                <h4 className="font-semibold text-gray-900">Update Frequency</h4>
              </div>
              
              <div className="space-y-2">
                {frequencyOptions.map((option) => (
                  <motion.label
                    key={option.value}
                    className={`flex items-center space-x-3 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                      settings.frequency === option.value
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <input
                      type="radio"
                      name="frequency"
                      value={option.value}
                      checked={settings.frequency === option.value}
                      onChange={(e) => updateSetting('frequency', e.target.value)}
                      className="sr-only"
                    />
                    <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                      settings.frequency === option.value
                        ? 'border-blue-500 bg-blue-500'
                        : 'border-gray-300'
                    }`}>
                      {settings.frequency === option.value && (
                        <div className="w-2 h-2 bg-white rounded-full" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">{option.label}</div>
                      <div className="text-sm text-gray-600">{option.description}</div>
                    </div>
                  </motion.label>
                ))}
              </div>
            </div>

            {/* Notification Types */}
            <div className={`space-y-4 ${!settings.enabled ? 'opacity-50 pointer-events-none' : ''}`}>
              <h4 className="font-semibold text-gray-900">Notification Types</h4>
              
              <div className="space-y-3">
                {notificationTypes.map((type) => (
                  <div key={type.key} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">{type.label}</div>
                      <div className="text-sm text-gray-600">{type.description}</div>
                    </div>
                    <motion.button
                      onClick={() => updateNotificationType(type.key as keyof NotificationSettings['types'], !settings.types[type.key as keyof NotificationSettings['types']])}
                      className={`relative w-10 h-5 rounded-full transition-colors ${
                        settings.types[type.key as keyof NotificationSettings['types']] ? 'bg-green-500' : 'bg-gray-300'
                      }`}
                      whileTap={{ scale: 0.95 }}
                    >
                      <motion.div
                        className="absolute top-0.5 w-4 h-4 bg-white rounded-full shadow-sm"
                        animate={{ x: settings.types[type.key as keyof NotificationSettings['types']] ? 22 : 2 }}
                        transition={{ type: "spring", stiffness: 500, damping: 30 }}
                      />
                    </motion.button>
                  </div>
                ))}
              </div>
            </div>

            {/* Additional Options */}
            <div className={`space-y-4 ${!settings.enabled ? 'opacity-50 pointer-events-none' : ''}`}>
              <h4 className="font-semibold text-gray-900">Additional Options</h4>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <div className="font-medium text-gray-900">Sound Alerts</div>
                    <div className="text-sm text-gray-600">Play sound for notifications</div>
                  </div>
                  <motion.button
                    onClick={() => updateSetting('sound', !settings.sound)}
                    className={`relative w-10 h-5 rounded-full transition-colors ${
                      settings.sound ? 'bg-blue-500' : 'bg-gray-300'
                    }`}
                    whileTap={{ scale: 0.95 }}
                  >
                    <motion.div
                      className="absolute top-0.5 w-4 h-4 bg-white rounded-full shadow-sm"
                      animate={{ x: settings.sound ? 22 : 2 }}
                      transition={{ type: "spring", stiffness: 500, damping: 30 }}
                    />
                  </motion.button>
                </div>

                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <div className="font-medium text-gray-900">Desktop Notifications</div>
                    <div className="text-sm text-gray-600">Show browser notifications</div>
                  </div>
                  <motion.button
                    onClick={() => updateSetting('desktop', !settings.desktop)}
                    className={`relative w-10 h-5 rounded-full transition-colors ${
                      settings.desktop ? 'bg-blue-500' : 'bg-gray-300'
                    }`}
                    whileTap={{ scale: 0.95 }}
                  >
                    <motion.div
                      className="absolute top-0.5 w-4 h-4 bg-white rounded-full shadow-sm"
                      animate={{ x: settings.desktop ? 22 : 2 }}
                      transition={{ type: "spring", stiffness: 500, damping: 30 }}
                    />
                  </motion.button>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="px-6 py-4 bg-gray-50 rounded-b-xl flex items-center justify-between">
            <motion.button
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:text-gray-900 transition-colors"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Cancel
            </motion.button>
            <motion.button
              onClick={handleSave}
              className="flex items-center space-x-2 px-6 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all shadow-lg"
              whileHover={{ scale: 1.02, boxShadow: "0 8px 25px -5px rgba(0, 0, 0, 0.1)" }}
              whileTap={{ scale: 0.98 }}
            >
              <Check className="w-4 h-4" />
              <span>Save Settings</span>
            </motion.button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};