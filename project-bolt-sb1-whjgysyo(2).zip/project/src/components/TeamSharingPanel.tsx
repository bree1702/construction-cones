import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Share2, Copy, Check, Users, Link, Mail, MessageSquare, QrCode, X } from 'lucide-react';
import toast from 'react-hot-toast';

interface TeamSharingPanelProps {
  isOpen: boolean;
  onClose: () => void;
  projectId: string;
  projectName: string;
  userRole: 'supervisor' | 'guest';
}

export const TeamSharingPanel: React.FC<TeamSharingPanelProps> = ({
  isOpen,
  onClose,
  projectId,
  projectName,
  userRole
}) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState<'link' | 'code' | 'qr'>('link');

  // Generate shareable link and project code
  const shareableLink = `${window.location.origin}?project=${projectId}&access=guest`;
  const projectCode = `PROJ-${new Date().getFullYear()}-${projectId.slice(-3).toUpperCase()}`;

  const copyToClipboard = async (text: string, type: 'link' | 'code') => {
    try {
      await navigator.clipboard.writeText(text);
      if (type === 'link') {
        setCopiedLink(true);
        setTimeout(() => setCopiedLink(false), 2000);
        toast.success('Link copied to clipboard!');
      } else {
        setCopiedCode(true);
        setTimeout(() => setCopiedCode(false), 2000);
        toast.success('Project code copied!');
      }
    } catch (err) {
      toast.error('Failed to copy to clipboard');
    }
  };

  const shareViaEmail = () => {
    const subject = `Access to Construction Project: ${projectName}`;
    const body = `Hi there!

You've been invited to view the construction project "${projectName}".

You can access the project in two ways:

1. Direct Link: ${shareableLink}

2. Manual Access:
   - Go to: ${window.location.origin}
   - Choose "Guest Access"
   - Enter project code: ${projectCode}

This will give you real-time access to:
• Live construction zone monitoring
• Smart cone status and locations
• AI insights and analytics
• Safety alerts and updates

Best regards,
Construction Team`;

    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  const shareViaWhatsApp = () => {
    const message = `🚧 Construction Project Access

Project: ${projectName}
Access Link: ${shareableLink}

Or use project code: ${projectCode}

View real-time construction data, smart cone monitoring, and AI insights!`;

    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
  };

  const generateQRCode = () => {
    // In a real implementation, you'd use a QR code library
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(shareableLink)}`;
    return qrUrl;
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="bg-white rounded-xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-orange-600 to-red-600 px-6 py-4 rounded-t-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-white/20 rounded-lg">
                  <Share2 className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">Share Project Access</h3>
                  <p className="text-orange-100 text-sm">Invite team members to view project data</p>
                </div>
              </div>
              <motion.button
                onClick={onClose}
                className="p-2 text-white/80 hover:text-white hover:bg-white/20 rounded-lg transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <X className="w-5 h-5" />
              </motion.button>
            </div>
          </div>

          <div className="p-6 space-y-6">
            {/* Project Info */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-900 mb-2">Project Details</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Project Name:</span>
                  <span className="font-medium text-gray-900">{projectName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Project ID:</span>
                  <span className="font-mono text-gray-900">{projectId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Your Role:</span>
                  <span className={`font-medium capitalize ${
                    userRole === 'supervisor' ? 'text-blue-700' : 'text-green-700'
                  }`}>
                    {userRole}
                  </span>
                </div>
              </div>
            </div>

            {/* Sharing Methods */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">Choose Sharing Method</h4>
              <div className="flex space-x-2 mb-4">
                {[
                  { id: 'link', label: 'Direct Link', icon: Link },
                  { id: 'code', label: 'Project Code', icon: Users },
                  { id: 'qr', label: 'QR Code', icon: QrCode }
                ].map((method) => {
                  const IconComponent = method.icon;
                  return (
                    <motion.button
                      key={method.id}
                      onClick={() => setSelectedMethod(method.id as any)}
                      className={`flex-1 flex items-center justify-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                        selectedMethod === method.id
                          ? 'bg-orange-100 text-orange-700 border-2 border-orange-300'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200 border-2 border-transparent'
                      }`}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <IconComponent className="w-4 h-4" />
                      <span className="hidden sm:inline">{method.label}</span>
                    </motion.button>
                  );
                })}
              </div>

              {/* Direct Link */}
              {selectedMethod === 'link' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-4"
                >
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <h5 className="font-medium text-blue-900 mb-2">Direct Access Link</h5>
                    <p className="text-sm text-blue-700 mb-3">
                      Share this link for instant access to the project dashboard
                    </p>
                    <div className="flex items-center space-x-2">
                      <input
                        type="text"
                        value={shareableLink}
                        readOnly
                        className="flex-1 px-3 py-2 bg-white border border-blue-300 rounded text-sm font-mono"
                      />
                      <motion.button
                        onClick={() => copyToClipboard(shareableLink, 'link')}
                        className="px-3 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      </motion.button>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Project Code */}
              {selectedMethod === 'code' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-4"
                >
                  <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                    <h5 className="font-medium text-green-900 mb-2">Project Access Code</h5>
                    <p className="text-sm text-green-700 mb-3">
                      Team members can use this code to access the project via guest login
                    </p>
                    <div className="flex items-center space-x-2">
                      <input
                        type="text"
                        value={projectCode}
                        readOnly
                        className="flex-1 px-3 py-2 bg-white border border-green-300 rounded text-lg font-mono font-bold text-center"
                      />
                      <motion.button
                        onClick={() => copyToClipboard(projectCode, 'code')}
                        className="px-3 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      </motion.button>
                    </div>
                    <div className="mt-3 p-3 bg-white rounded border border-green-200">
                      <p className="text-xs text-green-700">
                        <strong>Instructions for team members:</strong><br />
                        1. Go to the project website<br />
                        2. Click "Guest Access"<br />
                        3. Enter this project code<br />
                        4. Start viewing real-time data
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* QR Code */}
              {selectedMethod === 'qr' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-4"
                >
                  <div className="bg-purple-50 p-4 rounded-lg border border-purple-200 text-center">
                    <h5 className="font-medium text-purple-900 mb-2">QR Code Access</h5>
                    <p className="text-sm text-purple-700 mb-4">
                      Scan this QR code with any smartphone camera for instant access
                    </p>
                    <div className="flex justify-center mb-4">
                      <img
                        src={generateQRCode()}
                        alt="Project QR Code"
                        className="w-48 h-48 border border-purple-300 rounded-lg"
                      />
                    </div>
                    <p className="text-xs text-purple-600">
                      QR code contains the direct access link to the project dashboard
                    </p>
                  </div>
                </motion.div>
              )}
            </div>

            {/* Quick Share Options */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">Quick Share</h4>
              <div className="grid grid-cols-2 gap-3">
                <motion.button
                  onClick={shareViaEmail}
                  className="flex items-center justify-center space-x-2 px-4 py-3 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Mail className="w-4 h-4" />
                  <span className="text-sm font-medium">Email</span>
                </motion.button>

                <motion.button
                  onClick={shareViaWhatsApp}
                  className="flex items-center justify-center space-x-2 px-4 py-3 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <MessageSquare className="w-4 h-4" />
                  <span className="text-sm font-medium">WhatsApp</span>
                </motion.button>
              </div>
            </div>

            {/* Access Permissions */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <h5 className="font-medium text-gray-900 mb-2">Guest Access Includes:</h5>
              <ul className="text-sm text-gray-700 space-y-1">
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Real-time construction zone monitoring</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Smart cone status and locations</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>AI insights and analytics</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Safety alerts and notifications</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  <span>No editing or management capabilities</span>
                </li>
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};