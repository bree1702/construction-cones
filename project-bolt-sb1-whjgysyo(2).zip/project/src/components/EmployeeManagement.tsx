import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Users, Plus, Edit, Trash2, DollarSign, Clock, Search, Filter, Download, Mail } from 'lucide-react';
import toast from 'react-hot-toast';

interface Employee {
  id: string;
  name: string;
  email: string;
  position: string;
  payRate: number;
  hoursWorked: number;
  startDate: string;
  isActive: boolean;
  department: string;
  phoneNumber?: string;
}

interface EmployeeManagementProps {
  userPermissions?: {
    manageTeam: boolean;
    exportData: boolean;
  };
}

export const EmployeeManagement: React.FC<EmployeeManagementProps> = ({ userPermissions }) => {
  const [employees, setEmployees] = useState<Employee[]>([
    {
      id: '1',
      name: 'John Smith',
      email: 'john.smith@constructionzone.app',
      position: 'Site Supervisor',
      payRate: 35.50,
      hoursWorked: 168.5,
      startDate: '2024-01-15',
      isActive: true,
      department: 'Operations',
      phoneNumber: '(555) 123-4567'
    },
    {
      id: '2',
      name: 'Maria Garcia',
      email: 'maria.garcia@constructionzone.app',
      position: 'Safety Inspector',
      payRate: 32.00,
      hoursWorked: 156.0,
      startDate: '2024-02-01',
      isActive: true,
      department: 'Safety',
      phoneNumber: '(555) 234-5678'
    },
    {
      id: '3',
      name: 'David Johnson',
      email: 'david.johnson@constructionzone.app',
      position: 'Equipment Operator',
      payRate: 28.75,
      hoursWorked: 172.25,
      startDate: '2023-11-20',
      isActive: true,
      department: 'Operations',
      phoneNumber: '(555) 345-6789'
    },
    {
      id: '4',
      name: 'Sarah Wilson',
      email: 'sarah.wilson@constructionzone.app',
      position: 'Project Coordinator',
      payRate: 30.00,
      hoursWorked: 160.0,
      startDate: '2024-01-08',
      isActive: true,
      department: 'Management',
      phoneNumber: '(555) 456-7890'
    },
    {
      id: '5',
      name: 'Mike Brown',
      email: 'mike.brown@constructionzone.app',
      position: 'Flagman',
      payRate: 22.50,
      hoursWorked: 144.75,
      startDate: '2024-03-01',
      isActive: false,
      department: 'Traffic Control',
      phoneNumber: '(555) 567-8901'
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [filterDepartment, setFilterDepartment] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);

  const filteredEmployees = employees.filter(employee => {
    const matchesSearch = employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee.position.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesDepartment = filterDepartment === 'all' || employee.department === filterDepartment;
    const matchesStatus = filterStatus === 'all' || 
                         (filterStatus === 'active' && employee.isActive) ||
                         (filterStatus === 'inactive' && !employee.isActive);
    
    return matchesSearch && matchesDepartment && matchesStatus;
  });

  const departments = [...new Set(employees.map(emp => emp.department))];
  const totalPayroll = employees.filter(emp => emp.isActive).reduce((sum, emp) => sum + (emp.payRate * emp.hoursWorked), 0);
  const totalHours = employees.filter(emp => emp.isActive).reduce((sum, emp) => sum + emp.hoursWorked, 0);

  const handleAddEmployee = (employeeData: Omit<Employee, 'id'>) => {
    const newEmployee: Employee = {
      ...employeeData,
      id: Date.now().toString()
    };
    setEmployees(prev => [...prev, newEmployee]);
    toast.success(`Employee ${employeeData.name} added successfully!`);
  };

  const handleEditEmployee = (employeeData: Employee) => {
    setEmployees(prev => prev.map(emp => emp.id === employeeData.id ? employeeData : emp));
    toast.success(`Employee ${employeeData.name} updated successfully!`);
  };

  const handleDeleteEmployee = (employeeId: string) => {
    const employee = employees.find(emp => emp.id === employeeId);
    if (employee) {
      setEmployees(prev => prev.filter(emp => emp.id !== employeeId));
      toast.success(`Employee ${employee.name} removed successfully!`);
    }
  };

  const exportPayrollData = () => {
    if (!userPermissions?.exportData) {
      toast.error('You do not have permission to export data');
      return;
    }

    const csvData = employees.map(emp => ({
      Name: emp.name,
      Email: emp.email,
      Position: emp.position,
      Department: emp.department,
      'Pay Rate': `$${emp.payRate.toFixed(2)}`,
      'Hours Worked': emp.hoursWorked.toFixed(2),
      'Total Pay': `$${(emp.payRate * emp.hoursWorked).toFixed(2)}`,
      Status: emp.isActive ? 'Active' : 'Inactive',
      'Start Date': emp.startDate
    }));

    const csvContent = [
      Object.keys(csvData[0]).join(','),
      ...csvData.map(row => Object.values(row).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `payroll-report-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    
    toast.success('Payroll data exported successfully!');
  };

  const sendPayrollEmail = (employee: Employee) => {
    const subject = `Payroll Summary - ${new Date().toLocaleDateString()}`;
    const body = `Dear ${employee.name},

Here is your current payroll summary:

Position: ${employee.position}
Department: ${employee.department}
Pay Rate: $${employee.payRate.toFixed(2)}/hour
Hours Worked: ${employee.hoursWorked.toFixed(2)}
Total Earnings: $${(employee.payRate * employee.hoursWorked).toFixed(2)}

If you have any questions, please contact HR.

Best regards,
Construction Zone Management Team`;

    window.location.href = `mailto:${employee.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  return (
    <div className="space-y-6">
      {/* Header with Stats */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Users className="w-8 h-8" />
            <div>
              <h2 className="text-2xl font-bold">Employee Management</h2>
              <p className="text-blue-100">Manage team members and payroll</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-blue-100">Email Domain</p>
            <p className="text-lg font-semibold">@constructionzone.app</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white/20 rounded-lg p-4">
            <div className="flex items-center space-x-2">
              <Users className="w-5 h-5" />
              <span className="text-sm font-medium">Total Employees</span>
            </div>
            <p className="text-2xl font-bold mt-1">{employees.length}</p>
          </div>
          
          <div className="bg-white/20 rounded-lg p-4">
            <div className="flex items-center space-x-2">
              <Users className="w-5 h-5" />
              <span className="text-sm font-medium">Active</span>
            </div>
            <p className="text-2xl font-bold mt-1">{employees.filter(emp => emp.isActive).length}</p>
          </div>
          
          <div className="bg-white/20 rounded-lg p-4">
            <div className="flex items-center space-x-2">
              <Clock className="w-5 h-5" />
              <span className="text-sm font-medium">Total Hours</span>
            </div>
            <p className="text-2xl font-bold mt-1">{totalHours.toFixed(1)}</p>
          </div>
          
          <div className="bg-white/20 rounded-lg p-4">
            <div className="flex items-center space-x-2">
              <DollarSign className="w-5 h-5" />
              <span className="text-sm font-medium">Total Payroll</span>
            </div>
            <p className="text-2xl font-bold mt-1">${totalPayroll.toLocaleString()}</p>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 mb-6">
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search employees..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent w-full sm:w-64"
              />
            </div>
            
            <select
              value={filterDepartment}
              onChange={(e) => setFilterDepartment(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Departments</option>
              {departments.map(dept => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
            </select>
            
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
          
          <div className="flex space-x-3">
            {userPermissions?.exportData && (
              <motion.button
                onClick={exportPayrollData}
                className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Download className="w-4 h-4" />
                <span>Export</span>
              </motion.button>
            )}
            
            {userPermissions?.manageTeam && (
              <motion.button
                onClick={() => setShowAddModal(true)}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Plus className="w-4 h-4" />
                <span>Add Employee</span>
              </motion.button>
            )}
          </div>
        </div>

        {/* Employee Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Employee</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Position</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Department</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Pay Rate</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Hours</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Total Pay</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Status</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredEmployees.map((employee) => (
                <motion.tr
                  key={employee.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="border-b border-gray-100 hover:bg-gray-50"
                >
                  <td className="py-4 px-4">
                    <div>
                      <div className="font-medium text-gray-900">{employee.name}</div>
                      <div className="text-sm text-gray-500">{employee.email}</div>
                    </div>
                  </td>
                  <td className="py-4 px-4 text-gray-900">{employee.position}</td>
                  <td className="py-4 px-4 text-gray-900">{employee.department}</td>
                  <td className="py-4 px-4 text-gray-900">${employee.payRate.toFixed(2)}/hr</td>
                  <td className="py-4 px-4 text-gray-900">{employee.hoursWorked.toFixed(1)}</td>
                  <td className="py-4 px-4 text-gray-900 font-semibold">
                    ${(employee.payRate * employee.hoursWorked).toLocaleString()}
                  </td>
                  <td className="py-4 px-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      employee.isActive 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-red-100 text-red-700'
                    }`}>
                      {employee.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex space-x-2">
                      <motion.button
                        onClick={() => sendPayrollEmail(employee)}
                        className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        title="Send payroll email"
                      >
                        <Mail className="w-4 h-4" />
                      </motion.button>
                      
                      {userPermissions?.manageTeam && (
                        <>
                          <motion.button
                            onClick={() => setEditingEmployee(employee)}
                            className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            title="Edit employee"
                          >
                            <Edit className="w-4 h-4" />
                          </motion.button>
                          
                          <motion.button
                            onClick={() => handleDeleteEmployee(employee.id)}
                            className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-colors"
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            title="Delete employee"
                          >
                            <Trash2 className="w-4 h-4" />
                          </motion.button>
                        </>
                      )}
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredEmployees.length === 0 && (
          <div className="text-center py-12">
            <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 font-medium">No employees found</p>
            <p className="text-sm text-gray-400">Try adjusting your search or filters</p>
          </div>
        )}
      </div>

      {/* Add/Edit Employee Modal */}
      <EmployeeModal
        isOpen={showAddModal || editingEmployee !== null}
        onClose={() => {
          setShowAddModal(false);
          setEditingEmployee(null);
        }}
        onSave={editingEmployee ? handleEditEmployee : handleAddEmployee}
        employee={editingEmployee}
        departments={departments}
      />
    </div>
  );
};

interface EmployeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (employee: any) => void;
  employee?: Employee | null;
  departments: string[];
}

const EmployeeModal: React.FC<EmployeeModalProps> = ({
  isOpen,
  onClose,
  onSave,
  employee,
  departments
}) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    position: '',
    department: '',
    payRate: 0,
    hoursWorked: 0,
    startDate: '',
    isActive: true,
    phoneNumber: ''
  });

  React.useEffect(() => {
    if (employee) {
      setFormData({
        name: employee.name,
        email: employee.email,
        position: employee.position,
        department: employee.department,
        payRate: employee.payRate,
        hoursWorked: employee.hoursWorked,
        startDate: employee.startDate,
        isActive: employee.isActive,
        phoneNumber: employee.phoneNumber || ''
      });
    } else {
      setFormData({
        name: '',
        email: '',
        position: '',
        department: '',
        payRate: 0,
        hoursWorked: 0,
        startDate: new Date().toISOString().split('T')[0],
        isActive: true,
        phoneNumber: ''
      });
    }
  }, [employee]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.position) {
      toast.error('Please fill in all required fields');
      return;
    }

    const employeeData = {
      ...formData,
      email: formData.email.includes('@') ? formData.email : `${formData.email}@constructionzone.app`,
      id: employee?.id
    };

    onSave(employeeData);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        >
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-6 py-4 rounded-t-xl">
            <h3 className="text-xl font-semibold text-white">
              {employee ? 'Edit Employee' : 'Add New Employee'}
            </h3>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email *
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="username@constructionzone.app"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Position *
                </label>
                <input
                  type="text"
                  value={formData.position}
                  onChange={(e) => setFormData(prev => ({ ...prev, position: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Department
                </label>
                <select
                  value={formData.department}
                  onChange={(e) => setFormData(prev => ({ ...prev, department: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select Department</option>
                  {departments.map(dept => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                  <option value="Operations">Operations</option>
                  <option value="Safety">Safety</option>
                  <option value="Management">Management</option>
                  <option value="Traffic Control">Traffic Control</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Pay Rate ($/hour)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.payRate}
                  onChange={(e) => setFormData(prev => ({ ...prev, payRate: parseFloat(e.target.value) || 0 }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Hours Worked
                </label>
                <input
                  type="number"
                  step="0.25"
                  min="0"
                  value={formData.hoursWorked}
                  onChange={(e) => setFormData(prev => ({ ...prev, hoursWorked: parseFloat(e.target.value) || 0 }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Start Date
                </label>
                <input
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, startDate: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={formData.phoneNumber}
                  onChange={(e) => setFormData(prev => ({ ...prev, phoneNumber: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="(555) 123-4567"
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="isActive"
                checked={formData.isActive}
                onChange={(e) => setFormData(prev => ({ ...prev, isActive: e.target.checked }))}
                className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
              />
              <label htmlFor="isActive" className="text-sm font-medium text-gray-700">
                Active Employee
              </label>
            </div>

            <div className="flex justify-end space-x-3 pt-4">
              <motion.button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-gray-600 hover:text-gray-900 transition-colors"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Cancel
              </motion.button>
              <motion.button
                type="submit"
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                {employee ? 'Update' : 'Add'} Employee
              </motion.button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};