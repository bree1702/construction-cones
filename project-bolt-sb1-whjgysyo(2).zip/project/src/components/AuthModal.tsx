import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User, Shield, Users, Eye, Lock, Mail, Key, Copy, Check, Share2, Link } from 'lucide-react';
import toast from 'react-hot-toast';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuth: (user: UserProfile) => void;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: 'supervisor' | 'guest';
  projectId?: string;
  permissions: {
    viewAll: boolean;
    editZones: boolean;
    manageTeam: boolean;
    exportData: boolean;
  };
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onAuth }) => {
  const [authMode, setAuthMode] = useState<'signin' | 'supervisor' | 'guest'>('signin');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    projectCode: '',
    supervisorCode: ''
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleSupervisorSignIn = async () => {
    setIsLoading(true);
    
    // Simulate authentication
    setTimeout(() => {
      const supervisorUser: UserProfile = {
        id: 'sup_' + Date.now(),
        name: formData.name || 'Supervisor',
        email: formData.email,
        role: 'supervisor',
        permissions: {
          viewAll: true,
          editZones: true,
          manageTeam: true,
          exportData: true
        }
      };
      
      onAuth(supervisorUser);
      setIsLoading(false);
      toast.success('🔐 Supervisor access granted!');
    }, 1500);
  };

  const handleGuestSignIn = async () => {
    setIsLoading(true);
    
    // Simulate authentication
    setTimeout(() => {
      const guestUser: UserProfile = {
        id: 'guest_' + Date.now(),
        name: formData.name || 'Guest User',
        email: formData.email,
        role: 'guest',
        projectId: formData.projectCode,
        permissions: {
          viewAll: true,
          editZones: false,
          manageTeam: false,
          exportData: false
        }
      };
      
      onAuth(guestUser);
      setIsLoading(false);
      toast.success('👁️ Guest access granted!');
    }, 1000);
  };

  const updateFormData = (key: string, value: string) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="bg-white rounded-xl shadow-2xl max-w-md w-full"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-6 py-4 rounded-t-xl">
            <div className="text-center">
              <div className="flex justify-center mb-2">
                <div className="p-3 bg-white/20 rounded-full">
                  <Shield className="w-6 h-6 text-white" />
                </div>
              </div>
              <h3 className="text-xl font-bold text-white">Access Control</h3>
              <p className="text-blue-100 text-sm">Choose your access level</p>
            </div>
          </div>

          <div className="p-6">
            {authMode === 'signin' && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-4"
              >
                <div className="text-center mb-6">
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">Select Access Type</h4>
                  <p className="text-sm text-gray-600">Choose the appropriate access level for your role</p>
                </div>

                <motion.button
                  onClick={() => setAuthMode('supervisor')}
                  className="w-full p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all group"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className="flex items-center space-x-4">
                    <div className="p-3 bg-blue-100 rounded-lg group-hover:bg-blue-200 transition-colors">
                      <Shield className="w-6 h-6 text-blue-600" />
                    </div>
                    <div className="text-left flex-1">
                      <h5 className="font-semibold text-gray-900">Supervisor Access</h5>
                      <p className="text-sm text-gray-600">Full control and management capabilities</p>
                      <div className="flex flex-wrap gap-1 mt-2">
                        <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">Edit Zones</span>
                        <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">Manage Team</span>
                        <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">Export Data</span>
                      </div>
                    </div>
                  </div>
                </motion.button>

                <motion.button
                  onClick={() => setAuthMode('guest')}
                  className="w-full p-4 border-2 border-gray-200 rounded-lg hover:border-green-500 hover:bg-green-50 transition-all group"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className="flex items-center space-x-4">
                    <div className="p-3 bg-green-100 rounded-lg group-hover:bg-green-200 transition-colors">
                      <Eye className="w-6 h-6 text-green-600" />
                    </div>
                    <div className="text-left flex-1">
                      <h5 className="font-semibold text-gray-900">Guest Access</h5>
                      <p className="text-sm text-gray-600">View-only access with project code</p>
                      <div className="flex flex-wrap gap-1 mt-2">
                        <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">View Only</span>
                        <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Real-time Data</span>
                        <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Analytics</span>
                      </div>
                    </div>
                  </div>
                </motion.button>
              </motion.div>
            )}

            {authMode === 'supervisor' && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-4"
              >
                <div className="text-center mb-6">
                  <div className="flex justify-center mb-2">
                    <div className="p-3 bg-blue-100 rounded-full">
                      <Shield className="w-6 h-6 text-blue-600" />
                    </div>
                  </div>
                  <h4 className="text-lg font-semibold text-gray-900">Supervisor Sign In</h4>
                  <p className="text-sm text-gray-600">Enter your supervisor credentials</p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => updateFormData('name', e.target.value)}
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Enter your full name"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => updateFormData('email', e.target.value)}
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="supervisor@company.com"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Supervisor Code</label>
                    <div className="relative">
                      <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        type="password"
                        value={formData.supervisorCode}
                        onChange={(e) => updateFormData('supervisorCode', e.target.value)}
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Enter supervisor access code"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex space-x-3 pt-4">
                  <motion.button
                    onClick={() => setAuthMode('signin')}
                    className="flex-1 px-4 py-3 text-gray-600 hover:text-gray-900 transition-colors"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    Back
                  </motion.button>
                  <motion.button
                    onClick={handleSupervisorSignIn}
                    disabled={isLoading || !formData.name || !formData.email}
                    className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    {isLoading ? (
                      <div className="flex items-center justify-center space-x-2">
                        <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                        <span>Signing In...</span>
                      </div>
                    ) : (
                      'Sign In'
                    )}
                  </motion.button>
                </div>
              </motion.div>
            )}

            {authMode === 'guest' && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-4"
              >
                <div className="text-center mb-6">
                  <div className="flex justify-center mb-2">
                    <div className="p-3 bg-green-100 rounded-full">
                      <Eye className="w-6 h-6 text-green-600" />
                    </div>
                  </div>
                  <h4 className="text-lg font-semibold text-gray-900">Guest Access</h4>
                  <p className="text-sm text-gray-600">Enter project details to view construction data</p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Your Name</label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => updateFormData('name', e.target.value)}
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        placeholder="Enter your name"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email (Optional)</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => updateFormData('email', e.target.value)}
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        placeholder="your@email.com"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Project Access Code</label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        type="text"
                        value={formData.projectCode}
                        onChange={(e) => updateFormData('projectCode', e.target.value)}
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        placeholder="Enter project code (e.g., PROJ-2025-001)"
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      Get this code from your project supervisor or team lead
                    </p>
                  </div>
                </div>

                <div className="flex space-x-3 pt-4">
                  <motion.button
                    onClick={() => setAuthMode('signin')}
                    className="flex-1 px-4 py-3 text-gray-600 hover:text-gray-900 transition-colors"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    Back
                  </motion.button>
                  <motion.button
                    onClick={handleGuestSignIn}
                    disabled={isLoading || !formData.name || !formData.projectCode}
                    className="flex-1 px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    {isLoading ? (
                      <div className="flex items-center justify-center space-x-2">
                        <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                        <span>Accessing...</span>
                      </div>
                    ) : (
                      'Access Project'
                    )}
                  </motion.button>
                </div>
              </motion.div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};