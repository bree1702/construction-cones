import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Filter, Plus, BarChart3, Brain, Zap, X, Shield, Eye } from 'lucide-react';
import { ConstructionZone } from '../types';
import { ZoneCard } from './ZoneCard';
import { NewProjectModal } from './NewProjectModal';
import { UserProfile as UserProfileType } from './AuthModal';

interface SidebarProps {
  zones: ConstructionZone[];
  selectedZone: ConstructionZone | null;
  onZoneSelect: (zone: ConstructionZone) => void;
  searchTerm: string;
  onSearchChange: (term: string) => void;
  onClose?: () => void;
  currentUser?: UserProfileType;
  onAddZone?: (zone: Omit<ConstructionZone, 'id' | 'createdAt'>) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  zones,
  selectedZone,
  onZoneSelect,
  searchTerm,
  onSearchChange,
  onClose,
  currentUser,
  onAddZone
}) => {
  const [activeTab, setActiveTab] = useState<'zones' | 'analytics' | 'ai'>('zones');
  const [filterActive, setFilterActive] = useState(false);
  const [newProjectModalOpen, setNewProjectModalOpen] = useState(false);

  const filteredZones = zones.filter(zone =>
    zone.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
    (!filterActive || zone.isActive)
  );

  const tabs = [
    { id: 'zones', label: 'Zones', icon: Search, count: zones.length },
    { id: 'analytics', label: 'Analytics', icon: BarChart3, count: null },
    { id: 'ai', label: 'AI Insights', icon: Brain, count: 5 }
  ];

  const handleCreateProject = (projectData: Omit<ConstructionZone, 'id' | 'createdAt'>) => {
    if (onAddZone) {
      onAddZone(projectData);
      setNewProjectModalOpen(false);
    }
  };

  return (
    <>
      <div className="w-full h-full bg-gradient-to-b from-gray-50 to-white border-r border-gray-200 flex flex-col shadow-lg">
        {/* Header */}
        <div className="p-4 lg:p-6 bg-white border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="flex-1">
              <h2 className="text-lg font-bold text-gray-900">Control Center</h2>
              {currentUser && (
                <div className="flex items-center space-x-2 mt-1">
                  <div className={`p-1 rounded ${
                    currentUser.role === 'supervisor' ? 'bg-blue-100' : 'bg-green-100'
                  }`}>
                    {currentUser.role === 'supervisor' ? (
                      <Shield className="w-3 h-3 text-blue-600" />
                    ) : (
                      <Eye className="w-3 h-3 text-green-600" />
                    )}
                  </div>
                  <span className={`text-xs font-medium capitalize ${
                    currentUser.role === 'supervisor' ? 'text-blue-700' : 'text-green-700'
                  }`}>
                    {currentUser.role} Access
                  </span>
                </div>
              )}
            </div>
            <div className="flex items-center space-x-2">
              {currentUser?.permissions.editZones && (
                <motion.button 
                  onClick={() => setNewProjectModalOpen(true)}
                  className="flex items-center space-x-2 px-3 py-2 bg-gradient-to-r from-orange-600 to-red-600 text-white rounded-lg hover:from-orange-700 hover:to-red-700 transition-all shadow-lg text-sm"
                  whileHover={{ scale: 1.02, boxShadow: "0 8px 25px -5px rgba(0, 0, 0, 0.1)" }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Plus className="w-4 h-4" />
                  <span className="hidden sm:inline font-medium">New Project</span>
                </motion.button>
              )}
              
              {/* Close button for mobile */}
              {onClose && (
                <motion.button
                  onClick={onClose}
                  className="lg:hidden p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <X className="w-5 h-5" />
                </motion.button>
              )}
            </div>
          </div>
          
          {/* Tab Navigation */}
          <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg mb-4">
            {tabs.map((tab) => {
              const IconComponent = tab.icon;
              return (
                <motion.button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex-1 flex items-center justify-center space-x-1 lg:space-x-2 px-2 lg:px-3 py-2 rounded-md text-xs lg:text-sm font-medium transition-all ${
                    activeTab === tab.id
                      ? 'bg-white text-gray-900 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <IconComponent className="w-4 h-4" />
                  <span className="hidden sm:inline">{tab.label}</span>
                  {tab.count !== null && (
                    <span className="bg-gray-200 text-gray-700 text-xs px-2 py-0.5 rounded-full">
                      {tab.count}
                    </span>
                  )}
                </motion.button>
              );
            })}
          </div>

          {/* Search and Filters */}
          {activeTab === 'zones' && (
            <div className="space-y-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search zones..."
                  value={searchTerm}
                  onChange={(e) => onSearchChange(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all text-sm"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <motion.button 
                  onClick={() => setFilterActive(!filterActive)}
                  className={`flex items-center space-x-2 px-3 py-1.5 text-sm rounded-md transition-all ${
                    filterActive 
                      ? 'bg-orange-100 text-orange-700 border border-orange-200' 
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Filter className="w-4 h-4" />
                  <span>Active Only</span>
                </motion.button>
                
                <div className="flex items-center space-x-2 text-xs text-gray-500">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>{zones.filter(z => z.isActive).length} active</span>
                </div>
              </div>
            </div>
          )}
        </div>
        
        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          <AnimatePresence mode="wait">
            {activeTab === 'zones' && (
              <motion.div
                key="zones"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="p-3 lg:p-4 space-y-3 lg:space-y-4"
              >
                {filteredZones.length === 0 ? (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Search className="w-8 h-8 text-gray-400" />
                    </div>
                    <p className="text-gray-500 font-medium">
                      {zones.length === 0 ? 'No projects yet' : 'No zones found'}
                    </p>
                    <p className="text-sm text-gray-400 mt-1">
                      {zones.length === 0 
                        ? 'Create your first construction project to get started'
                        : 'Try adjusting your search or filters'
                      }
                    </p>
                    {currentUser?.permissions.editZones && (
                      <motion.button
                        onClick={() => setNewProjectModalOpen(true)}
                        className="mt-4 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        {zones.length === 0 ? 'Create First Project' : 'Create New Project'}
                      </motion.button>
                    )}
                  </div>
                ) : (
                  filteredZones.map((zone, index) => (
                    <motion.div
                      key={zone.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <ZoneCard
                        zone={zone}
                        onSelect={onZoneSelect}
                        isSelected={selectedZone?.id === zone.id}
                        userPermissions={currentUser?.permissions}
                      />
                    </motion.div>
                  ))
                )}
              </motion.div>
            )}

            {activeTab === 'analytics' && (
              <motion.div
                key="analytics"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="p-3 lg:p-4 space-y-3 lg:space-y-4"
              >
                <div className="bg-gradient-to-br from-blue-50 to-cyan-100 p-4 lg:p-6 rounded-xl border border-blue-200">
                  <h3 className="font-semibold text-blue-900 mb-4">Quick Stats</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-blue-700 text-sm">Total Devices</span>
                      <span className="font-bold text-blue-900">{zones.flatMap(z => z.cones).length}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-blue-700 text-sm">Avg Battery</span>
                      <span className="font-bold text-blue-900">87%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-blue-700 text-sm">Risk Score</span>
                      <span className="font-bold text-blue-900">23/100</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-blue-700 text-sm">Access Level</span>
                      <span className={`font-bold capitalize ${
                        currentUser?.role === 'supervisor' ? 'text-blue-900' : 'text-green-900'
                      }`}>
                        {currentUser?.role || 'Guest'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-green-50 to-emerald-100 p-4 lg:p-6 rounded-xl border border-green-200">
                  <h3 className="font-semibold text-green-900 mb-4">Performance</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-green-700 text-sm">Uptime</span>
                      <span className="font-bold text-green-900">99.2%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-green-700 text-sm">Response Time</span>
                      <span className="font-bold text-green-900">1.2s</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-green-700 text-sm">Efficiency</span>
                      <span className="font-bold text-green-900">94%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-green-700 text-sm">Data Export</span>
                      <span className={`font-bold ${
                        currentUser?.permissions.exportData ? 'text-green-900' : 'text-gray-500'
                      }`}>
                        {currentUser?.permissions.exportData ? 'Available' : 'Restricted'}
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'ai' && (
              <motion.div
                key="ai"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="p-3 lg:p-4 space-y-3 lg:space-y-4"
              >
                <div className="bg-gradient-to-br from-purple-50 to-pink-100 p-4 lg:p-6 rounded-xl border border-purple-200">
                  <div className="flex items-center space-x-2 mb-4">
                    <Zap className="w-5 h-5 text-purple-600" />
                    <h3 className="font-semibold text-purple-900">AI Status</h3>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span className="text-sm text-purple-700">Predictive analysis active</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                      <span className="text-sm text-purple-700">Traffic optimization running</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
                      <span className="text-sm text-purple-700">Safety monitoring enabled</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`w-2 h-2 rounded-full ${
                        currentUser?.role === 'supervisor' ? 'bg-blue-500' : 'bg-green-500'
                      }`}></div>
                      <span className="text-sm text-purple-700">
                        {currentUser?.role === 'supervisor' ? 'Full AI access' : 'View-only AI insights'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900">Recent Insights</h4>
                  {[
                    { type: 'safety', message: 'Cone density optimization suggested', time: '2m ago' },
                    { type: 'efficiency', message: 'Traffic flow improved by 15%', time: '5m ago' },
                    { type: 'maintenance', message: '3 devices need inspection', time: '12m ago' }
                  ].map((insight, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="bg-white p-3 lg:p-4 rounded-lg border border-gray-200 shadow-sm"
                    >
                      <div className="flex items-start space-x-3">
                        <div className={`w-2 h-2 rounded-full mt-2 ${
                          insight.type === 'safety' ? 'bg-red-500' :
                          insight.type === 'efficiency' ? 'bg-green-500' : 'bg-blue-500'
                        }`}></div>
                        <div className="flex-1">
                          <p className="text-sm text-gray-900 font-medium">{insight.message}</p>
                          <p className="text-xs text-gray-500 mt-1">{insight.time}</p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* New Project Modal */}
      {newProjectModalOpen && (
        <NewProjectModal
          isOpen={newProjectModalOpen}
          onClose={() => setNewProjectModalOpen(false)}
          onCreateProject={handleCreateProject}
          userPermissions={currentUser?.permissions}
        />
      )}
    </>
  );
};