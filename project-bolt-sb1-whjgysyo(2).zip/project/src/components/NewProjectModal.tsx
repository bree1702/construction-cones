import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, X, MapPin, Calendar, Users, AlertTriangle, Save, Upload, Map, Check } from 'lucide-react';
import toast from 'react-hot-toast';
import { ConstructionZone, Cone } from '../types';

interface NewProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateProject: (project: Omit<ConstructionZone, 'id' | 'createdAt'>) => void;
  userPermissions?: {
    editZones: boolean;
  };
}

export const NewProjectModal: React.FC<NewProjectModalProps> = ({
  isOpen,
  onClose,
  onCreateProject,
  userPermissions
}) => {
  const [step, setStep] = useState<'basic' | 'location' | 'cones' | 'review'>('basic');
  const [isCreating, setIsCreating] = useState(false);
  const [projectData, setProjectData] = useState({
    name: '',
    description: '',
    location: '',
    estimatedDuration: '',
    workersCount: 5,
    priority: 'medium' as 'low' | 'medium' | 'high',
    safetyLevel: 'standard' as 'standard' | 'high' | 'critical',
    coordinates: { lat: 39.0, lng: -116.2 },
    cones: [] as Omit<Cone, 'id' | 'timestamp'>[]
  });

  const updateProjectData = (key: string, value: any) => {
    setProjectData(prev => ({ ...prev, [key]: value }));
  };

  const addCone = () => {
    const newCone = {
      lat: projectData.coordinates.lat + (Math.random() - 0.5) * 0.01,
      lng: projectData.coordinates.lng + (Math.random() - 0.5) * 0.01,
      type: 'warning' as const,
      batteryLevel: 100,
      temperature: 22,
      vibrationLevel: 0,
      isConnected: true,
      predictedFailure: 0
    };
    
    updateProjectData('cones', [...projectData.cones, newCone]);
  };

  const removeCone = (index: number) => {
    const updatedCones = projectData.cones.filter((_, i) => i !== index);
    updateProjectData('cones', updatedCones);
  };

  const handleCreateProject = async () => {
    if (!userPermissions?.editZones) {
      toast.error('You do not have permission to create projects');
      return;
    }

    if (!projectData.name.trim()) {
      toast.error('Project name is required');
      return;
    }

    if (!projectData.location.trim()) {
      toast.error('Project location is required');
      return;
    }

    if (projectData.cones.length === 0) {
      toast.error('At least one cone is required');
      return;
    }

    setIsCreating(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const newProject: Omit<ConstructionZone, 'id' | 'createdAt'> = {
        name: projectData.name,
        cones: projectData.cones.map((cone, index) => ({
          ...cone,
          id: `cone_${Date.now()}_${index}`,
          timestamp: new Date().toISOString()
        })),
        isActive: true,
        riskScore: Math.floor(Math.random() * 30) + 10,
        weatherConditions: {
          temperature: 20 + Math.random() * 10,
          humidity: 50 + Math.random() * 30,
          windSpeed: Math.random() * 15,
          visibility: 8 + Math.random() * 2,
          conditions: ['Clear', 'Partly Cloudy', 'Overcast'][Math.floor(Math.random() * 3)],
          forecast: 'Stable conditions expected'
        },
        trafficFlow: {
          currentFlow: 700 + Math.random() * 300,
          averageSpeed: 35 + Math.random() * 20,
          congestionLevel: (['low', 'medium'] as const)[Math.floor(Math.random() * 2)],
          accidentRisk: Math.random() * 25,
          alternativeRoutes: Math.floor(Math.random() * 4) + 2
        },
        aiRecommendations: [
          'Optimal cone placement detected for current traffic patterns',
          'Consider additional lighting for evening work periods',
          'Monitor weather conditions for next 48 hours',
          'Traffic flow analysis suggests peak hours: 7-9 AM, 5-7 PM'
        ],
        estimatedCompletion: projectData.estimatedDuration,
        workersCount: projectData.workersCount,
        safetyIncidents: 0
      };

      onCreateProject(newProject);
      onClose();
      resetForm();
    } catch (error) {
      toast.error('Failed to create project. Please try again.');
    } finally {
      setIsCreating(false);
    }
  };

  const resetForm = () => {
    setStep('basic');
    setProjectData({
      name: '',
      description: '',
      location: '',
      estimatedDuration: '',
      workersCount: 5,
      priority: 'medium',
      safetyLevel: 'standard',
      coordinates: { lat: 39.0, lng: -116.2 },
      cones: []
    });
  };

  const nextStep = () => {
    const steps = ['basic', 'location', 'cones', 'review'];
    const currentIndex = steps.indexOf(step);
    if (currentIndex < steps.length - 1) {
      setStep(steps[currentIndex + 1] as any);
    }
  };

  const prevStep = () => {
    const steps = ['basic', 'location', 'cones', 'review'];
    const currentIndex = steps.indexOf(step);
    if (currentIndex > 0) {
      setStep(steps[currentIndex - 1] as any);
    }
  };

  const canProceed = () => {
    switch (step) {
      case 'basic':
        return projectData.name.trim() && projectData.location.trim();
      case 'location':
        return projectData.coordinates.lat && projectData.coordinates.lng;
      case 'cones':
        return projectData.cones.length > 0;
      case 'review':
        return true;
      default:
        return false;
    }
  };

  const getStepValidation = () => {
    switch (step) {
      case 'basic':
        if (!projectData.name.trim()) return 'Project name is required';
        if (!projectData.location.trim()) return 'Location is required';
        return null;
      case 'location':
        if (!projectData.coordinates.lat || !projectData.coordinates.lng) return 'Valid coordinates are required';
        return null;
      case 'cones':
        if (projectData.cones.length === 0) return 'At least one cone is required';
        return null;
      default:
        return null;
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-orange-600 to-red-600 px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-white/20 rounded-lg">
                  <Plus className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white">Create New Project</h3>
                  <p className="text-orange-100 text-sm">Set up a new construction zone</p>
                </div>
              </div>
              <motion.button
                onClick={() => {
                  onClose();
                  resetForm();
                }}
                className="p-2 text-white/80 hover:text-white hover:bg-white/20 rounded-lg transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <X className="w-6 h-6" />
              </motion.button>
            </div>

            {/* Progress Steps */}
            <div className="mt-4 flex items-center justify-between">
              {['Basic Info', 'Location', 'Cones', 'Review'].map((stepName, index) => {
                const stepIds = ['basic', 'location', 'cones', 'review'];
                const currentStepIndex = stepIds.indexOf(step);
                const isActive = index === currentStepIndex;
                const isCompleted = index < currentStepIndex;
                
                return (
                  <div key={stepName} className="flex items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all ${
                      isActive ? 'bg-white text-orange-600' :
                      isCompleted ? 'bg-orange-300 text-orange-800' :
                      'bg-white/20 text-white/60'
                    }`}>
                      {isCompleted ? <Check className="w-4 h-4" /> : index + 1}
                    </div>
                    <span className={`ml-2 text-sm font-medium hidden sm:inline ${
                      isActive ? 'text-white' : 'text-white/60'
                    }`}>
                      {stepName}
                    </span>
                    {index < 3 && <div className="w-4 sm:w-8 h-0.5 bg-white/20 mx-2 sm:mx-3" />}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Content */}
          <div className="p-6 overflow-y-auto max-h-[60vh]">
            {/* Validation Message */}
            {getStepValidation() && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg"
              >
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                  <span className="text-sm text-red-700">{getStepValidation()}</span>
                </div>
              </motion.div>
            )}

            <AnimatePresence mode="wait">
              {/* Basic Info Step */}
              {step === 'basic' && (
                <motion.div
                  key="basic"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Project Information</h4>
                    
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Project Name *
                        </label>
                        <input
                          type="text"
                          value={projectData.name}
                          onChange={(e) => updateProjectData('name', e.target.value)}
                          className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent ${
                            !projectData.name.trim() ? 'border-red-300' : 'border-gray-300'
                          }`}
                          placeholder="e.g., Highway 95 Expansion"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Location *
                        </label>
                        <input
                          type="text"
                          value={projectData.location}
                          onChange={(e) => updateProjectData('location', e.target.value)}
                          className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent ${
                            !projectData.location.trim() ? 'border-red-300' : 'border-gray-300'
                          }`}
                          placeholder="e.g., Las Vegas, NV - Mile Marker 15"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Description
                        </label>
                        <textarea
                          value={projectData.description}
                          onChange={(e) => updateProjectData('description', e.target.value)}
                          rows={3}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                          placeholder="Brief description of the construction project..."
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Estimated Duration
                          </label>
                          <select
                            value={projectData.estimatedDuration}
                            onChange={(e) => updateProjectData('estimatedDuration', e.target.value)}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                          >
                            <option value="">Select duration</option>
                            <option value="1-3 days">1-3 days</option>
                            <option value="1 week">1 week</option>
                            <option value="2-4 weeks">2-4 weeks</option>
                            <option value="1-3 months">1-3 months</option>
                            <option value="3+ months">3+ months</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Workers Count
                          </label>
                          <input
                            type="number"
                            min="1"
                            max="50"
                            value={projectData.workersCount}
                            onChange={(e) => updateProjectData('workersCount', Math.max(1, parseInt(e.target.value) || 1))}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Priority Level
                          </label>
                          <select
                            value={projectData.priority}
                            onChange={(e) => updateProjectData('priority', e.target.value)}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                          >
                            <option value="low">Low Priority</option>
                            <option value="medium">Medium Priority</option>
                            <option value="high">High Priority</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Safety Level
                          </label>
                          <select
                            value={projectData.safetyLevel}
                            onChange={(e) => updateProjectData('safetyLevel', e.target.value)}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                          >
                            <option value="standard">Standard</option>
                            <option value="high">High Risk</option>
                            <option value="critical">Critical</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Location Step */}
              {step === 'location' && (
                <motion.div
                  key="location"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Project Location</h4>
                    
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Latitude *
                          </label>
                          <input
                            type="number"
                            step="0.000001"
                            value={projectData.coordinates.lat}
                            onChange={(e) => {
                              const lat = parseFloat(e.target.value);
                              if (!isNaN(lat)) {
                                updateProjectData('coordinates', {
                                  ...projectData.coordinates,
                                  lat: lat
                                });
                              }
                            }}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                            placeholder="39.000000"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Longitude *
                          </label>
                          <input
                            type="number"
                            step="0.000001"
                            value={projectData.coordinates.lng}
                            onChange={(e) => {
                              const lng = parseFloat(e.target.value);
                              if (!isNaN(lng)) {
                                updateProjectData('coordinates', {
                                  ...projectData.coordinates,
                                  lng: lng
                                });
                              }
                            }}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                            placeholder="-116.200000"
                          />
                        </div>
                      </div>

                      <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                        <div className="flex items-center space-x-2 mb-2">
                          <Map className="w-5 h-5 text-blue-600" />
                          <h5 className="font-medium text-blue-900">Location Preview</h5>
                        </div>
                        <p className="text-sm text-blue-700">
                          Coordinates: {projectData.coordinates.lat.toFixed(6)}, {projectData.coordinates.lng.toFixed(6)}
                        </p>
                        <p className="text-xs text-blue-600 mt-1">
                          Smart cones will be deployed around this central location
                        </p>
                      </div>

                      <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                        <div className="flex items-start space-x-2">
                          <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                          <div>
                            <h5 className="font-medium text-yellow-900">Location Tips</h5>
                            <ul className="text-sm text-yellow-700 mt-1 space-y-1">
                              <li>• Use GPS coordinates from the actual construction site</li>
                              <li>• Ensure coordinates are within your operational area</li>
                              <li>• Consider traffic patterns and accessibility</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Cones Step */}
              {step === 'cones' && (
                <motion.div
                  key="cones"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-lg font-semibold text-gray-900">Smart Cone Deployment</h4>
                      <motion.button
                        onClick={addCone}
                        className="flex items-center space-x-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add Cone</span>
                      </motion.button>
                    </div>

                    {projectData.cones.length === 0 ? (
                      <div className="text-center py-12 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
                        <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                        <h5 className="text-lg font-medium text-gray-900 mb-2">No Cones Added</h5>
                        <p className="text-gray-600 mb-4">Add smart cones to define your construction zone</p>
                        <motion.button
                          onClick={addCone}
                          className="px-6 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          Add First Cone
                        </motion.button>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                          <p className="text-sm text-green-700">
                            <strong>{projectData.cones.length} smart cone{projectData.cones.length !== 1 ? 's' : ''}</strong> will be deployed around your project location
                          </p>
                        </div>

                        <div className="max-h-60 overflow-y-auto space-y-2">
                          {projectData.cones.map((cone, index) => (
                            <motion.div
                              key={index}
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              className="flex items-center justify-between p-3 bg-white border border-gray-200 rounded-lg"
                            >
                              <div className="flex items-center space-x-3">
                                <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                                <div>
                                  <p className="text-sm font-medium text-gray-900">
                                    Cone #{index + 1}
                                  </p>
                                  <p className="text-xs text-gray-500">
                                    {cone.lat.toFixed(6)}, {cone.lng.toFixed(6)}
                                  </p>
                                </div>
                              </div>
                              <motion.button
                                onClick={() => removeCone(index)}
                                className="p-1 text-red-600 hover:bg-red-50 rounded"
                                whileHover={{ scale: 1.1 }}
                                whileTap={{ scale: 0.9 }}
                              >
                                <X className="w-4 h-4" />
                              </motion.button>
                            </motion.div>
                          ))}
                        </div>

                        <div className="flex space-x-2">
                          <motion.button
                            onClick={() => {
                              // Add multiple cones at once
                              for (let i = 0; i < 5; i++) {
                                addCone();
                              }
                            }}
                            className="flex-1 px-4 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors text-sm"
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                          >
                            Add 5 Cones
                          </motion.button>
                          <motion.button
                            onClick={() => {
                              updateProjectData('cones', []);
                            }}
                            className="px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors text-sm"
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                          >
                            Clear All
                          </motion.button>
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {/* Review Step */}
              {step === 'review' && (
                <motion.div
                  key="review"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Review Project Details</h4>
                    
                    <div className="space-y-4">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h5 className="font-medium text-gray-900 mb-3">Project Information</h5>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-gray-600">Name:</span>
                            <p className="font-medium">{projectData.name}</p>
                          </div>
                          <div>
                            <span className="text-gray-600">Location:</span>
                            <p className="font-medium">{projectData.location}</p>
                          </div>
                          <div>
                            <span className="text-gray-600">Duration:</span>
                            <p className="font-medium">{projectData.estimatedDuration || 'Not specified'}</p>
                          </div>
                          <div>
                            <span className="text-gray-600">Workers:</span>
                            <p className="font-medium">{projectData.workersCount}</p>
                          </div>
                          <div>
                            <span className="text-gray-600">Priority:</span>
                            <p className={`font-medium capitalize ${
                              projectData.priority === 'high' ? 'text-red-600' :
                              projectData.priority === 'medium' ? 'text-yellow-600' :
                              'text-green-600'
                            }`}>
                              {projectData.priority}
                            </p>
                          </div>
                          <div>
                            <span className="text-gray-600">Safety Level:</span>
                            <p className={`font-medium capitalize ${
                              projectData.safetyLevel === 'critical' ? 'text-red-600' :
                              projectData.safetyLevel === 'high' ? 'text-orange-600' :
                              'text-blue-600'
                            }`}>
                              {projectData.safetyLevel}
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                        <h5 className="font-medium text-blue-900 mb-3">Deployment Summary</h5>
                        <div className="text-sm text-blue-700 space-y-1">
                          <p>• <strong>{projectData.cones.length} smart cone{projectData.cones.length !== 1 ? 's' : ''}</strong> will be deployed</p>
                          <p>• Real-time monitoring will begin immediately</p>
                          <p>• AI analysis will provide safety insights</p>
                          <p>• Team members can access via project sharing</p>
                          <p>• Location: {projectData.coordinates.lat.toFixed(4)}, {projectData.coordinates.lng.toFixed(4)}</p>
                        </div>
                      </div>

                      {projectData.description && (
                        <div className="bg-gray-50 p-4 rounded-lg">
                          <h5 className="font-medium text-gray-900 mb-2">Description</h5>
                          <p className="text-sm text-gray-700">{projectData.description}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Footer */}
          <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
            <div className="flex space-x-3">
              {step !== 'basic' && (
                <motion.button
                  onClick={prevStep}
                  className="px-4 py-2 text-gray-600 hover:text-gray-900 transition-colors"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Previous
                </motion.button>
              )}
            </div>

            <div className="flex space-x-3">
              <motion.button
                onClick={() => {
                  onClose();
                  resetForm();
                }}
                className="px-4 py-2 text-gray-600 hover:text-gray-900 transition-colors"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Cancel
              </motion.button>

              {step === 'review' ? (
                <motion.button
                  onClick={handleCreateProject}
                  disabled={isCreating || !userPermissions?.editZones}
                  className="flex items-center space-x-2 px-6 py-2 bg-gradient-to-r from-orange-600 to-red-600 text-white rounded-lg hover:from-orange-700 hover:to-red-700 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                  whileHover={{ scale: 1.02, boxShadow: "0 8px 25px -5px rgba(0, 0, 0, 0.1)" }}
                  whileTap={{ scale: 0.98 }}
                >
                  {isCreating ? (
                    <>
                      <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                      <span>Creating...</span>
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4" />
                      <span>Create Project</span>
                    </>
                  )}
                </motion.button>
              ) : (
                <motion.button
                  onClick={nextStep}
                  disabled={!canProceed()}
                  className="px-6 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Next
                </motion.button>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};