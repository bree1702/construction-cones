import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { MapContainer, TileLayer, Marker, Popup, useMap, Circle, Polyline } from 'react-leaflet';
import L from 'leaflet';
import { ConstructionZone, Cone } from '../types';
import { Battery, Thermometer, Activity, AlertTriangle, Wifi, WifiOff } from 'lucide-react';

// Fix for default markers in react-leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Smart cone icons with different states
const createConeIcon = (cone: Cone) => {
  const batteryLevel = cone.batteryLevel || 100;
  const isConnected = cone.isConnected !== false;
  const riskLevel = cone.predictedFailure || 0;
  
  let color = '#10B981'; // Green for healthy
  if (riskLevel > 70) color = '#EF4444'; // Red for high risk
  else if (riskLevel > 40) color = '#F59E0B'; // Orange for medium risk
  else if (batteryLevel < 20) color = '#F59E0B'; // Orange for low battery
  
  if (!isConnected) color = '#6B7280'; // Gray for offline

  return new L.Icon({
    iconUrl: 'data:image/svg+xml;base64,' + btoa(`
      <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="16" cy="16" r="15" fill="${color}" stroke="white" stroke-width="2" opacity="0.9"/>
        <path d="M16 6L10 26H22L16 6Z" fill="white" stroke="${color}" stroke-width="1"/>
        <circle cx="16" cy="12" r="2" fill="${color}"/>
        ${!isConnected ? '<line x1="8" y1="8" x2="24" y2="24" stroke="white" stroke-width="2"/>' : ''}
        ${batteryLevel < 20 ? '<rect x="12" y="20" width="8" height="4" fill="white" rx="1"/>' : ''}
      </svg>
    `),
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32],
  });
};

interface MapViewProps {
  zones: ConstructionZone[];
  selectedZone: ConstructionZone | null;
}

const MapController: React.FC<{ selectedZone: ConstructionZone | null }> = ({ selectedZone }) => {
  const map = useMap();
  
  useEffect(() => {
    if (selectedZone && selectedZone.cones.length > 0) {
      const bounds = L.latLngBounds(
        selectedZone.cones.map(cone => [cone.lat, cone.lng])
      );
      map.fitBounds(bounds, { padding: [20, 20] });
    }
  }, [selectedZone, map]);
  
  return null;
};

export const MapView: React.FC<MapViewProps> = ({ zones, selectedZone }) => {
  const allCones = zones.flatMap(zone => 
    zone.cones.map(cone => ({ ...cone, zoneName: zone.name, zoneActive: zone.isActive }))
  );

  const center: [number, number] = selectedZone && selectedZone.cones.length > 0
    ? [selectedZone.cones[0].lat, selectedZone.cones[0].lng]
    : [39.0, -116.2];

  // Generate AI-suggested optimal paths
  const generateOptimalPath = (cones: Cone[]) => {
    if (cones.length < 2) return [];
    return cones.map(cone => [cone.lat, cone.lng] as [number, number]);
  };

  const getBatteryColor = (level: number) => {
    if (level > 60) return '#10B981';
    if (level > 30) return '#F59E0B';
    return '#EF4444';
  };

  const getRiskColor = (risk: number) => {
    if (risk < 30) return '#10B981';
    if (risk < 70) return '#F59E0B';
    return '#EF4444';
  };

  return (
    <div className="h-full w-full rounded-xl overflow-hidden shadow-lg relative">
      <MapContainer
        center={center}
        zoom={10}
        className="h-full w-full"
        zoomControl={true}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        <MapController selectedZone={selectedZone} />
        
        {/* AI-suggested optimal paths */}
        {selectedZone && (
          <Polyline
            positions={generateOptimalPath(selectedZone.cones)}
            color="#8B5CF6"
            weight={3}
            opacity={0.7}
            dashArray="10, 10"
          />
        )}
        
        {/* Safety zones around high-risk areas */}
        {allCones
          .filter(cone => (cone.predictedFailure || 0) > 70)
          .map(cone => (
            <Circle
              key={`safety-${cone.id}`}
              center={[cone.lat, cone.lng]}
              radius={100}
              color="#EF4444"
              fillColor="#EF4444"
              fillOpacity={0.1}
              weight={2}
              opacity={0.5}
            />
          ))}
        
        {/* Smart cone markers */}
        {allCones.map((cone) => (
          <Marker
            key={cone.id}
            position={[cone.lat, cone.lng]}
            icon={createConeIcon(cone)}
          >
            <Popup className="custom-popup" maxWidth={320}>
              <motion.div 
                className="p-3 lg:p-4 min-w-[280px] lg:min-w-[300px]"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
              >
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-bold text-gray-900 text-base lg:text-lg">{(cone as any).zoneName}</h4>
                  <div className="flex items-center space-x-2">
                    {cone.isConnected !== false ? (
                      <Wifi className="w-4 h-4 text-green-600" />
                    ) : (
                      <WifiOff className="w-4 h-4 text-red-600" />
                    )}
                    <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                      (cone as any).zoneActive 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-gray-100 text-gray-600'
                    }`}>
                      {(cone as any).zoneActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-3 lg:gap-4 mb-4">
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <div className="flex items-center space-x-2 mb-1">
                      <Battery className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium text-gray-700">Battery</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div 
                          className="h-2 rounded-full transition-all duration-300"
                          style={{ 
                            width: `${cone.batteryLevel || 100}%`,
                            backgroundColor: getBatteryColor(cone.batteryLevel || 100)
                          }}
                        ></div>
                      </div>
                      <span className="text-sm font-bold text-gray-900">
                        {Math.round(cone.batteryLevel || 100)}%
                      </span>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-3 rounded-lg">
                    <div className="flex items-center space-x-2 mb-1">
                      <Thermometer className="w-4 h-4 text-orange-600" />
                      <span className="text-sm font-medium text-gray-700">Temperature</span>
                    </div>
                    <span className="text-lg font-bold text-gray-900">
                      {Math.round(cone.temperature || 22)}°C
                    </span>
                  </div>

                  <div className="bg-gray-50 p-3 rounded-lg">
                    <div className="flex items-center space-x-2 mb-1">
                      <Activity className="w-4 h-4 text-purple-600" />
                      <span className="text-sm font-medium text-gray-700">Vibration</span>
                    </div>
                    <span className="text-lg font-bold text-gray-900">
                      {(cone.vibrationLevel || 0).toFixed(1)}
                    </span>
                  </div>

                  <div className="bg-gray-50 p-3 rounded-lg">
                    <div className="flex items-center space-x-2 mb-1">
                      <AlertTriangle className="w-4 h-4 text-red-600" />
                      <span className="text-sm font-medium text-gray-700">Risk Score</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span 
                        className="text-lg font-bold"
                        style={{ color: getRiskColor(cone.predictedFailure || 0) }}
                      >
                        {Math.round(cone.predictedFailure || 0)}
                      </span>
                      <span className="text-xs text-gray-500">/100</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2 text-sm border-t pt-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Coordinates:</span>
                    <span className="font-mono text-gray-900 text-xs">
                      {cone.lat.toFixed(6)}, {cone.lng.toFixed(6)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Deployed:</span>
                    <span className="text-gray-900 text-xs">
                      {new Date(cone.timestamp).toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Last Maintenance:</span>
                    <span className="text-gray-900 text-xs">
                      {cone.lastMaintenance ? new Date(cone.lastMaintenance).toLocaleDateString() : 'N/A'}
                    </span>
                  </div>
                </div>

                {(cone.predictedFailure || 0) > 70 && (
                  <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <AlertTriangle className="w-4 h-4 text-red-600" />
                      <span className="text-sm font-medium text-red-800">High Risk Alert</span>
                    </div>
                    <p className="text-xs text-red-700 mt-1">
                      This device requires immediate attention. Schedule maintenance ASAP.
                    </p>
                  </div>
                )}
              </motion.div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>

      {/* AI Insights Overlay */}
      <div className="absolute top-2 lg:top-4 right-2 lg:right-4 bg-white/90 backdrop-blur-sm rounded-lg p-2 lg:p-3 shadow-lg border border-gray-200">
        <div className="flex items-center space-x-2 mb-2">
          <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse"></div>
          <span className="text-xs lg:text-sm font-medium text-gray-700">AI Analysis Active</span>
        </div>
        <div className="text-xs text-gray-600 space-y-1">
          <div>• Optimal path suggested</div>
          <div>• Risk zones highlighted</div>
          <div>• Real-time monitoring</div>
        </div>
      </div>
    </div>
  );
};