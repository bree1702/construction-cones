import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Construction, MapPin, Settings, Brain, Zap, Activity, Bell, BellOff, Menu } from 'lucide-react';
import { NotificationSettings } from './NotificationSettings';
import { SettingsModal } from './SettingsModal';
import { UserProfile as UserProfileType } from './AuthModal';

interface HeaderProps {
  activeZones: number;
  totalCones: number;
  connectedDevices?: number;
  aiInsightsCount?: number;
  onMenuClick?: () => void;
  onNotificationSettingsClick?: () => void;
  notificationSettings?: {
    enabled: boolean;
    frequency: string;
  };
  currentUser?: UserProfileType;
  onUserProfileClick?: () => void;
  onOpenSharing?: () => void;
  onLogout?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  activeZones, 
  totalCones, 
  connectedDevices = 0,
  aiInsightsCount = 0,
  onMenuClick,
  onNotificationSettingsClick,
  notificationSettings,
  currentUser
}) => {
  const [notifications, setNotifications] = useState(3);
  const [settingsModalOpen, setSettingsModalOpen] = useState(false);

  return (
    <>
      <header className="bg-white shadow-sm border-b border-gray-200 relative overflow-hidden">
        {/* Animated background gradient */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-50/50 via-purple-50/30 to-orange-50/50"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-14 lg:h-16">
            <div className="flex items-center space-x-3 lg:space-x-4">
              {/* Mobile menu button */}
              <motion.button
                onClick={onMenuClick}
                className="lg:hidden p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Menu className="w-5 h-5" />
              </motion.button>

              <motion.div 
                className="flex items-center justify-center w-10 h-10 lg:w-12 lg:h-12 bg-gradient-to-br from-orange-500 to-red-600 rounded-xl shadow-lg"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Construction className="w-5 h-5 lg:w-7 lg:h-7 text-white" />
              </motion.div>
              <div>
                <h1 className="text-lg lg:text-xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
                  <span className="hidden sm:inline">AI Construction Zone Manager</span>
                  <span className="sm:hidden">AI Manager</span>
                </h1>
                <p className="text-xs lg:text-sm text-gray-500 flex items-center space-x-2">
                  <span className="hidden md:inline">Real-time monitoring & AI insights</span>
                  <span className="md:hidden">Live monitoring</span>
                  <motion.div
                    className="w-2 h-2 bg-green-500 rounded-full"
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ repeat: Infinity, duration: 2 }}
                  />
                  {currentUser && (
                    <span className="text-xs bg-gray-100 px-2 py-1 rounded-full">
                      {currentUser.role === 'supervisor' ? '👑' : '👁️'} {currentUser.name}
                    </span>
                  )}
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2 lg:space-x-6">
              {/* Real-time metrics - Responsive layout */}
              <div className="hidden md:flex items-center space-x-2 lg:space-x-6">
                <motion.div 
                  className="flex items-center space-x-1 lg:space-x-2 bg-green-50 px-2 lg:px-3 py-1 lg:py-2 rounded-lg border border-green-200"
                  whileHover={{ scale: 1.02 }}
                >
                  <div className="w-2 h-2 lg:w-3 lg:h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-xs lg:text-sm font-semibold text-green-700">{activeZones} Active</span>
                </motion.div>
                
                <motion.div 
                  className="flex items-center space-x-1 lg:space-x-2 bg-blue-50 px-2 lg:px-3 py-1 lg:py-2 rounded-lg border border-blue-200"
                  whileHover={{ scale: 1.02 }}
                >
                  <MapPin className="w-3 h-3 lg:w-4 lg:h-4 text-blue-600" />
                  <span className="text-xs lg:text-sm font-semibold text-blue-700">{totalCones} Cones</span>
                </motion.div>

                <motion.div 
                  className="hidden lg:flex items-center space-x-2 bg-purple-50 px-3 py-2 rounded-lg border border-purple-200"
                  whileHover={{ scale: 1.02 }}
                >
                  <Activity className="w-4 h-4 text-purple-600" />
                  <span className="text-sm font-semibold text-purple-700">{connectedDevices} Connected</span>
                </motion.div>

                <motion.div 
                  className="hidden lg:flex items-center space-x-2 bg-orange-50 px-3 py-2 rounded-lg border border-orange-200"
                  whileHover={{ scale: 1.02 }}
                >
                  <Brain className="w-4 h-4 text-orange-600" />
                  <span className="text-sm font-semibold text-orange-700">{aiInsightsCount} AI Insights</span>
                </motion.div>
              </div>
              
              {/* Action buttons */}
              <div className="flex items-center space-x-2 lg:space-x-3">
                <motion.button 
                  onClick={onNotificationSettingsClick}
                  className="relative p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  title="Notification Settings"
                >
                  {notificationSettings?.enabled ? (
                    <Bell className="w-4 h-4 lg:w-5 lg:h-5" />
                  ) : (
                    <BellOff className="w-4 h-4 lg:w-5 lg:h-5" />
                  )}
                  {notifications > 0 && notificationSettings?.enabled && (
                    <motion.span 
                      className="absolute -top-1 -right-1 w-4 h-4 lg:w-5 lg:h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", stiffness: 500, damping: 30 }}
                    >
                      {notifications}
                    </motion.span>
                  )}
                </motion.button>

                <motion.button 
                  onClick={() => setSettingsModalOpen(true)}
                  className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  title="Application Settings"
                >
                  <Settings className="w-4 h-4 lg:w-5 lg:h-5" />
                </motion.button>

                <motion.button 
                  className="flex items-center space-x-1 lg:space-x-2 px-2 lg:px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all shadow-lg"
                  whileHover={{ scale: 1.02, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Zap className="w-3 h-3 lg:w-4 lg:h-4" />
                  <span className="text-xs lg:text-sm font-medium hidden sm:inline">AI Mode</span>
                </motion.button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={settingsModalOpen}
        onClose={() => setSettingsModalOpen(false)}
        currentUser={currentUser}
      />
    </>
  );
};