import { useState, useEffect } from 'react';
import { AIInsight, ConstructionZone, PredictiveAlert } from '../types';

// Simulated AI insights generation
export const useAIInsights = (zones: ConstructionZone[]) => {
  const [insights, setInsights] = useState<AIInsight[]>([]);
  const [alerts, setAlerts] = useState<PredictiveAlert[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  useEffect(() => {
    if (zones.length === 0) return;

    setIsAnalyzing(true);
    
    // Simulate AI analysis delay
    const timer = setTimeout(() => {
      const generatedInsights = generateAIInsights(zones);
      const generatedAlerts = generatePredictiveAlerts(zones);
      
      setInsights(generatedInsights);
      setAlerts(generatedAlerts);
      setIsAnalyzing(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, [zones]);

  return { insights, alerts, isAnalyzing };
};

const generateAIInsights = (zones: ConstructionZone[]): AIInsight[] => {
  const insights: AIInsight[] = [];
  
  zones.forEach(zone => {
    // Safety insights
    if (zone.cones.length > 15) {
      insights.push({
        id: `safety-${zone.id}`,
        type: 'safety',
        priority: 'high',
        title: 'High Cone Density Detected',
        description: `Zone ${zone.name} has ${zone.cones.length} cones in a concentrated area`,
        recommendation: 'Consider redistributing cones for optimal traffic flow and worker safety',
        confidence: 87,
        timestamp: new Date().toISOString()
      });
    }

    // Efficiency insights
    insights.push({
      id: `efficiency-${zone.id}`,
      type: 'efficiency',
      priority: 'medium',
      title: 'Optimal Cone Placement Analysis',
      description: 'AI analysis suggests 23% improvement in traffic flow possible',
      recommendation: 'Relocate 3 cones to positions marked on map for better efficiency',
      confidence: 92,
      timestamp: new Date().toISOString()
    });

    // Maintenance insights
    const oldCones = zone.cones.filter(cone => {
      const daysSinceDeployment = (Date.now() - new Date(cone.timestamp).getTime()) / (1000 * 60 * 60 * 24);
      return daysSinceDeployment > 7;
    });

    if (oldCones.length > 0) {
      insights.push({
        id: `maintenance-${zone.id}`,
        type: 'maintenance',
        priority: 'medium',
        title: 'Maintenance Schedule Optimization',
        description: `${oldCones.length} cones require inspection based on deployment duration`,
        recommendation: 'Schedule maintenance check within 48 hours',
        confidence: 78,
        timestamp: new Date().toISOString()
      });
    }
  });

  return insights;
};

const generatePredictiveAlerts = (zones: ConstructionZone[]): PredictiveAlert[] => {
  const alerts: PredictiveAlert[] = [];

  zones.forEach(zone => {
    // Weather-based predictions
    alerts.push({
      id: `weather-${zone.id}`,
      zoneId: zone.id,
      type: 'weather_warning',
      severity: 'warning',
      message: 'High winds predicted in 4 hours - secure loose equipment',
      timeToEvent: 240,
      confidence: 85,
      actions: ['Secure signage', 'Check cone stability', 'Alert workers']
    });

    // Traffic surge prediction
    alerts.push({
      id: `traffic-${zone.id}`,
      zoneId: zone.id,
      type: 'traffic_surge',
      severity: 'info',
      message: 'Rush hour traffic surge expected - 40% increase in volume',
      timeToEvent: 120,
      confidence: 94,
      actions: ['Deploy additional flaggers', 'Activate dynamic signage', 'Monitor closely']
    });
  });

  return alerts;
};