import { useState, useEffect } from 'react';
import { ConstructionZone, WeatherData, TrafficData } from '../types';

interface NotificationSettings {
  enabled: boolean;
  frequency: 'realtime' | '5min' | '10min' | '30min' | '1hour';
  types: {
    aiInsights: boolean;
    alerts: boolean;
    systemStatus: boolean;
    maintenance: boolean;
  };
  sound: boolean;
  desktop: boolean;
}

export const useRealTimeData = (zones: ConstructionZone[], notificationSettings: NotificationSettings) => {
  const [realTimeZones, setRealTimeZones] = useState<ConstructionZone[]>(zones);

  useEffect(() => {
    if (!notificationSettings.enabled) return;

    // Convert frequency to milliseconds
    const getUpdateInterval = (frequency: string) => {
      switch (frequency) {
        case 'realtime': return 5000; // 5 seconds for real-time
        case '5min': return 300000; // 5 minutes
        case '10min': return 600000; // 10 minutes
        case '30min': return 1800000; // 30 minutes
        case '1hour': return 3600000; // 1 hour
        default: return 600000; // Default to 10 minutes
      }
    };

    const interval = setInterval(() => {
      setRealTimeZones(prevZones => 
        prevZones.map(zone => ({
          ...zone,
          cones: zone.cones.map(cone => ({
            ...cone,
            batteryLevel: Math.max(0, (cone.batteryLevel || 100) - Math.random() * 0.5),
            temperature: 20 + Math.random() * 15,
            vibrationLevel: Math.random() * 10,
            isConnected: Math.random() > 0.05, // 95% uptime
            predictedFailure: Math.random() * 100
          })),
          riskScore: Math.floor(Math.random() * 100),
          weatherConditions: generateWeatherData(),
          trafficFlow: generateTrafficData(),
          aiRecommendations: generateRecommendations(),
          workersCount: Math.floor(Math.random() * 12) + 3,
          safetyIncidents: Math.floor(Math.random() * 3)
        }))
      );
    }, getUpdateInterval(notificationSettings.frequency));

    return () => clearInterval(interval);
  }, [notificationSettings.enabled, notificationSettings.frequency]);

  useEffect(() => {
    setRealTimeZones(zones.map(zone => ({
      ...zone,
      cones: zone.cones.map(cone => ({
        ...cone,
        batteryLevel: 85 + Math.random() * 15,
        temperature: 22 + Math.random() * 8,
        vibrationLevel: Math.random() * 5,
        isConnected: true,
        predictedFailure: Math.random() * 30
      })),
      riskScore: Math.floor(Math.random() * 40) + 10,
      weatherConditions: generateWeatherData(),
      trafficFlow: generateTrafficData(),
      aiRecommendations: generateRecommendations(),
      workersCount: Math.floor(Math.random() * 8) + 4,
      safetyIncidents: 0
    })));
  }, [zones]);

  return realTimeZones;
};

const generateWeatherData = (): WeatherData => ({
  temperature: 18 + Math.random() * 12,
  humidity: 40 + Math.random() * 40,
  windSpeed: Math.random() * 25,
  visibility: 8 + Math.random() * 2,
  conditions: ['Clear', 'Partly Cloudy', 'Overcast', 'Light Rain'][Math.floor(Math.random() * 4)],
  forecast: 'Improving conditions expected'
});

const generateTrafficData = (): TrafficData => ({
  currentFlow: 800 + Math.random() * 400,
  averageSpeed: 35 + Math.random() * 20,
  congestionLevel: (['low', 'medium', 'high'] as const)[Math.floor(Math.random() * 3)],
  accidentRisk: Math.random() * 100,
  alternativeRoutes: Math.floor(Math.random() * 5) + 2
});

const generateRecommendations = (): string[] => {
  const recommendations = [
    'Optimize cone spacing for better visibility',
    'Consider additional lighting for night work',
    'Deploy speed monitoring equipment',
    'Increase worker safety barriers',
    'Implement dynamic message signs'
  ];
  
  return recommendations.slice(0, Math.floor(Math.random() * 3) + 1);
};