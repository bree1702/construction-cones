import { useState, useEffect } from 'react';

interface WeatherData {
  temperature: number;
  humidity: number;
  windSpeed: number;
  visibility: number;
  conditions: string;
  forecast: string;
  location: string;
  pressure: number;
  uvIndex: number;
  feelsLike: number;
}

interface LocationCoords {
  latitude: number;
  longitude: number;
}

export const useWeatherData = () => {
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [location, setLocation] = useState<LocationCoords | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Get user's current location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
        },
        (error) => {
          console.warn('Geolocation error:', error);
          // Fallback to Las Vegas coordinates
          setLocation({
            latitude: 36.1699,
            longitude: -115.1398
          });
        }
      );
    } else {
      // Fallback to Las Vegas coordinates
      setLocation({
        latitude: 36.1699,
        longitude: -115.1398
      });
    }
  }, []);

  // Fetch weather data when location is available
  useEffect(() => {
    if (!location) return;

    const fetchWeatherData = async () => {
      try {
        setLoading(true);
        
        // Using OpenWeatherMap API (free tier)
        // Note: In production, you'd want to use your own API key
        const API_KEY = 'demo'; // Replace with actual API key
        const url = `https://api.openweathermap.org/data/2.5/weather?lat=${location.latitude}&lon=${location.longitude}&appid=${API_KEY}&units=metric`;
        
        // For demo purposes, we'll simulate weather data based on location
        const simulatedWeather = generateSimulatedWeather(location);
        
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        setWeatherData(simulatedWeather);
        setError(null);
      } catch (err) {
        console.error('Weather fetch error:', err);
        setError('Failed to fetch weather data');
        
        // Fallback to simulated data
        const fallbackWeather = generateSimulatedWeather(location);
        setWeatherData(fallbackWeather);
      } finally {
        setLoading(false);
      }
    };

    fetchWeatherData();
    
    // Update weather data every 10 minutes
    const interval = setInterval(fetchWeatherData, 10 * 60 * 1000);
    
    return () => clearInterval(interval);
  }, [location]);

  return { weatherData, location, loading, error };
};

// Generate realistic weather data based on location and time
const generateSimulatedWeather = (location: LocationCoords): WeatherData => {
  const now = new Date();
  const hour = now.getHours();
  const month = now.getMonth();
  
  // Base temperature varies by location and season
  let baseTemp = 20; // Default 20°C
  
  // Adjust for latitude (colder as you go north)
  baseTemp -= (location.latitude - 30) * 0.5;
  
  // Seasonal adjustment
  const seasonalAdjustment = Math.sin((month - 3) * Math.PI / 6) * 15;
  baseTemp += seasonalAdjustment;
  
  // Daily temperature variation
  const dailyVariation = Math.sin((hour - 6) * Math.PI / 12) * 8;
  const temperature = baseTemp + dailyVariation + (Math.random() - 0.5) * 4;
  
  // Generate other weather parameters
  const humidity = 40 + Math.random() * 40;
  const windSpeed = Math.random() * 20;
  const pressure = 1013 + (Math.random() - 0.5) * 40;
  const uvIndex = Math.max(0, Math.min(11, (hour - 6) / 6 * 8 + Math.random() * 2));
  const feelsLike = temperature + (humidity > 70 ? 2 : 0) + (windSpeed > 15 ? -2 : 0);
  
  // Determine conditions based on parameters
  let conditions = 'Clear';
  if (humidity > 80) conditions = 'Humid';
  if (windSpeed > 15) conditions = 'Windy';
  if (Math.random() > 0.8) conditions = 'Partly Cloudy';
  if (Math.random() > 0.9) conditions = 'Overcast';
  
  // Generate location name
  const locationName = getLocationName(location);
  
  return {
    temperature: Math.round(temperature * 10) / 10,
    humidity: Math.round(humidity),
    windSpeed: Math.round(windSpeed * 10) / 10,
    visibility: 8 + Math.random() * 2,
    conditions,
    forecast: generateForecast(conditions, temperature),
    location: locationName,
    pressure: Math.round(pressure),
    uvIndex: Math.round(uvIndex * 10) / 10,
    feelsLike: Math.round(feelsLike * 10) / 10
  };
};

const getLocationName = (location: LocationCoords): string => {
  // Simple location mapping - in production, use reverse geocoding
  if (location.latitude > 35 && location.latitude < 37 && location.longitude > -116 && location.longitude < -114) {
    return 'Las Vegas, NV';
  }
  if (location.latitude > 33 && location.latitude < 35 && location.longitude > -119 && location.longitude < -117) {
    return 'Los Angeles, CA';
  }
  if (location.latitude > 37 && location.latitude < 38 && location.longitude > -123 && location.longitude < -121) {
    return 'San Francisco, CA';
  }
  return `${location.latitude.toFixed(2)}°N, ${Math.abs(location.longitude).toFixed(2)}°W`;
};

const generateForecast = (conditions: string, temperature: number): string => {
  const forecasts = [
    'Stable conditions expected for the next 24 hours',
    'Slight temperature variation throughout the day',
    'Good conditions for construction work',
    'Monitor for potential weather changes',
    'Optimal working conditions predicted'
  ];
  
  if (temperature > 30) {
    return 'Hot conditions - ensure worker hydration and shade';
  }
  if (temperature < 5) {
    return 'Cold conditions - monitor equipment performance';
  }
  if (conditions.includes('Windy')) {
    return 'Windy conditions - secure loose equipment and signage';
  }
  
  return forecasts[Math.floor(Math.random() * forecasts.length)];
};