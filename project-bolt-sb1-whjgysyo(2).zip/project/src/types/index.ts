export interface Cone {
  id: string;
  lat: number;
  lng: number;
  timestamp: string;
  type: 'warning' | 'danger' | 'info';
  batteryLevel?: number;
  temperature?: number;
  vibrationLevel?: number;
  isConnected?: boolean;
  lastMaintenance?: string;
  predictedFailure?: number; // 0-100 risk score
}

export interface ConstructionZone {
  id: string;
  name: string;
  cones: Cone[];
  isActive: boolean;
  createdAt: string;
  riskScore?: number;
  weatherConditions?: WeatherData;
  trafficFlow?: TrafficData;
  aiRecommendations?: string[];
  estimatedCompletion?: string;
  workersCount?: number;
  safetyIncidents?: number;
}

export interface WeatherData {
  temperature: number;
  humidity: number;
  windSpeed: number;
  visibility: number;
  conditions: string;
  forecast: string;
}

export interface TrafficData {
  currentFlow: number;
  averageSpeed: number;
  congestionLevel: 'low' | 'medium' | 'high';
  accidentRisk: number;
  alternativeRoutes: number;
}

export interface AIInsight {
  id: string;
  type: 'safety' | 'efficiency' | 'maintenance' | 'traffic';
  priority: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  recommendation: string;
  confidence: number;
  timestamp: string;
}

export interface PredictiveAlert {
  id: string;
  zoneId: string;
  type: 'equipment_failure' | 'weather_warning' | 'traffic_surge' | 'safety_risk';
  severity: 'info' | 'warning' | 'critical';
  message: string;
  timeToEvent: number; // minutes
  confidence: number;
  actions: string[];
}